from semantic_dataset import SemanticDataset
import torch.utils.data
import torch
from open3d.ml.torch.datasets import Semantic3D


dataset = Semantic3D(
    dataset_path="./semantic_raw",
    split="train",
    download=True  # Set True if you'd like to attempt an auto-download
)

print(len(dataset))