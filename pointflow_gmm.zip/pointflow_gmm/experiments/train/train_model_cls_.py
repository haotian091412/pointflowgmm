import argparse
import datetime
import yaml
import os
import sys
import shutil

parent_path = os.path.dirname(os.path.dirname(os.path.abspath(os.path.dirname(__file__))))

sys.path.append(parent_path)

os.environ["CUDA_VISIBLE_DEVICES"] = "1"
import tqdm
from collections import OrderedDict
import open3d as o3d
import torch
from torch import distributions
from torch.utils.data import DataLoader
import numpy as np
from torch.nn import functional as F
from data.datasets_pointflow_ModelNet import (
#     CIFDatasetDecorator,
    ModelNet10PointClouds,
    CIFDatasetDecoratorMultiObject,
)
from data.datasets_pointflow_Modelnet_new import (
    ModelNet
)

# from data.datasets_Pointflow_IntrA import (
#     CIFDatasetDecorator,
#     IntrAPointCloud,
#     CIFDatasetDecoratorMultiObject,
# )
from utils.losses import loss_fun, loss_fun_cls, loss_fun_one

from models.models import model_init, model_load, model_init_pointnet, model_load_pointnet
from models.flows import F_flow, G_flow
from models.pointnet import Encoder
from models.pointnet2_model import Pointnet2
from models.distributions import SSLGaussMixture
from models.flow_loss import FlowLoss
# from experiments.test.metrics_eval import metrics_eval
from models.flows import F_inv_flow
from utils.model_utils import *
from torch.utils.tensorboard import SummaryWriter
from scipy.stats import ortho_group
import random


def get_mean(shape=(32), r=1, num_means=2, device=None):
    D = np.prod(shape)
    means = torch.zeros((num_means, D)).to(device)
    for i in range(num_means):
        means[i] = r * torch.randn(D)
    return means


def main(config: argparse.Namespace):
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    means_e = get_mean(shape=(config["emb_dim"]), r=1, num_means=5, device=device)
    # means_z = get_mean(shape=(3), r=3, num_means=5, device=device)
    n_means = 10  # 组数
    n_dim_z = 3  # 维数

    # 随机生成第一组均值
    means_z = np.random.randn(n_dim_z).reshape(1, -1)

    # 生成其余组均值
    while means_z.shape[0] < n_means:
        new_mean = 4.0 * np.random.randn(n_dim_z).reshape(1, -1)
        dists = np.linalg.norm(means_z - new_mean, axis=1)
        if np.min(dists) >= 5:
            means_z = np.vstack((means_z, new_mean))
    means_z = torch.from_numpy(means_z).to(device).float()
    n_means = 10  # 组数
    n_dim_e = config["emb_dim"]  # 维数

    # 随机生成第一组均值
    means_e = np.random.randn(n_dim_e).reshape(1, -1)

    # 生成其余组均值
    while means_e.shape[0] < n_means:
        new_mean = 4.0 * np.random.randn(n_dim_e).reshape(1, -1)
        dists = np.linalg.norm(means_e - new_mean, axis=1)
        if np.min(dists) >= 12:
            means_e = np.vstack((means_e, new_mean))
    means_e = torch.from_numpy(means_e).to(device).float()
    prior_e = SSLGaussMixture(means_e, device=device)
    prior_z = SSLGaussMixture(means_z, device=device)
    # prior_e = distributions.MultivariateNormal(
    #     torch.zeros(32), torch.eye(32)
    # )
    # prior_z = distributions.MultivariateNormal(
    #     torch.zeros(3), torch.eye(3)
    # )

    Ae, Az = torch.tensor(ortho_group.rvs(dim=config['emb_dim'])).to(device).float(), torch.tensor(
        ortho_group.rvs(dim=3)).to(device).float()
    # for i in range(40):
    #     z = prior_z.sample((2048,), gaussian_id=i)
    #     np.savetxt('output{}.xyz'.format(i), z.cpu().numpy(), fmt='%f %f %f')
    # prior_z = distributions.MultivariateNormal(
    #     torch.zeros(3), torch.eye(3)
    # )
    # prior_e = distributions.MultivariateNormal(
    #     torch.zeros(config["emb_dim"]), torch.eye(config["emb_dim"])
    # )

    if config["use_random_dataloader"]:
        tr_sample_size = config["tr_sample_size"]
        te_sample_size = config["te_sample_size"]
        batch_size = config["batch_size_if_random_split"]
    else:
        tr_sample_size = config["tr_sample_size"]
        te_sample_size = config["te_sample_size"]
        batch_size = config["batch_size"]

    # cloud_pointflow = ModelNet10PointClouds(
    #     tr_sample_size=tr_sample_size,
    #     te_sample_size=te_sample_size,
    #     root_dir=config["root_dir"],
    #     root_embs_dir=config["root_embs_dir"],
    #     normalize_per_shape=config["normalize_per_shape"],
    #     normalize_std_per_axis=config["normalize_std_per_axis"],
    #     split=["train"],
    #     scale=config["scale"],
    #     random_subsample=True,
    # )
    #
    # test_cloud = ModelNet10PointClouds(
    #     tr_sample_size=tr_sample_size,
    #     te_sample_size=te_sample_size,
    #     root_dir=config["root_dir"],
    #     root_embs_dir=config["root_embs_dir"],
    #     normalize_per_shape=config["normalize_per_shape"],
    #     normalize_std_per_axis=config["normalize_std_per_axis"],
    #     split=["train"],
    #     scale=config["scale"],
    #     random_subsample=True,
    # )
    data_cls = ModelNet_cls(config)
    processed_data = ModelNet(config)

    if config["load_models"] == False:
        if os.path.exists(config["save_models_dir"]):
            shutil.rmtree(config["save_models_dir"])
            os.makedirs(config["save_models_dir"])
            shutil.rmtree(config["save_models_dir"].replace('weight', 'weight_best'))
            os.makedirs(config["save_models_dir"].replace('weight', 'weight_best'))
            print('Delete old models')
    # if not os.path.exists(config["save_models_dir_backup"]):
    #     os.makedirs(config["save_models_dir_backup"])
    # dataloader_pointflow = DataLoader(
    #     cloud_pointflow, batch_size=batch_size, shuffle=True
    # )
    #
    # test_dataloader = DataLoader(
    #     test_cloud, batch_size=batch_size, shuffle=True
    # )
    dataloader_cls = DataLoader(
        data_cls, batch_size=batch_size, shuffle=True
    )
    # cloud_pointflow = CIFDatasetDecoratorMultiObject(
    #     cloud_pointflow, config["num_of_points_per_object"]
    # )
    dataloader = DataLoader(
        cloud_pointflow, batch_size=batch_size, shuffle=True
    )
    # np.save(
    #     os.path.join(config["save_models_dir"], "train_set_mean.npy"),
    #     cloud_pointflow.all_points_mean,
    # )
    # np.save(
    #     os.path.join(config["save_models_dir"], "train_set_std.npy"),
    #     cloud_pointflow.all_points_std,
    # )
    # np.save(
    #     os.path.join(config["save_models_dir"], "train_set_idx.npy"),
    #     np.array(cloud_pointflow.shuffle_idx),
    # )
    # np.save(
    #     os.path.join(config["save_models_dir"], "val_set_mean.npy"),
    #     cloud_pointflow.all_points_mean,
    # )
    # np.save(
    #     os.path.join(config["save_models_dir"], "val_set_std.npy"),
    #     cloud_pointflow.all_points_std,
    # )
    # np.save(
    #     os.path.join(config["save_models_dir"], "val_set_idx.npy"),
    #     np.array(cloud_pointflow.shuffle_idx),
    # )
    # pointnet = Encoder(
    #     load_pretrained=config["load_pretrained"],
    #     pretrained_path=config["pretrained_path"],
    #     zdim=config["emb_dim"],
    # ).to(device)
    pointnet = Pointnet2(
        emb_dim=config["emb_dim"],
        normal_channel=False
    ).to(device)

    if config["load_models"]:
        F_flows, G_flows, optimizer, scheduler, pointnet = model_load_pointnet(config, device, pointnet)
        means = torch.load(config["load_models_dir"] + "weight/" + "means.pth")
        means_z = means['means_z']
        means_e = means['means_e']
        prior_e = SSLGaussMixture(means_e, device=device)
        prior_z = SSLGaussMixture(means_z, device=device)
        # A = torch.load(config["load_models_dir"] + "weight/" + "A.pth")
        # Ae = A['Ae']
        # Az = A['Az']

    else:
        F_flows, G_flows, pointnet = model_init_pointnet(config, device, pointnet)

    if config['subset'] == 'train':
        print('start training')
        if config['get_inv'] == True:
            get_means(means_z,config['save_samples_dir'])
            get_inv(pointnet, F_flows, G_flows, prior_e, prior_z, cloud_pointflow, device, config,
                    config['save_samples_dir'], means_z)
        else:
            optimizer = optim_model(G_flows,F_flows, config['l_rate'], pointnet)
            scheduler = torch.optim.lr_scheduler.StepLR(optimizer, step_size=10, gamma=0.8)
            train(F_flows, G_flows, optimizer, scheduler, pointnet, dataloader, device, config, prior_e, prior_z,
                  means_e, means_z)

    elif config['subset'] == 'test':
        print('start testing')
        if config['get_inv'] == True:
            get_inv(pointnet, F_flows, G_flows, prior_e, prior_z, cloud_pointflow, device, config,
                    config['save_samples_dir'], means_z)
        else:
            test(pointnet, F_flows, G_flows, prior_e, prior_z, dataloader, device, config)


    else:
        print('please choose the subset')


def train(F_flows, G_flows, optimizer, scheduler, pointnet, dataloader, device, config, prior_e, prior_z, means_e,
          means_z):
    for key in F_flows:
        F_flows[key].train()

    for key in G_flows:
        G_flows[key].train()
    pointnet.train()

    train_writer = SummaryWriter(config["tensorboard_dir"] + "train")
    valid_writer = SummaryWriter(config["tensorboard_dir"] + "valid")

    global_step = 0
    best_e = 0

    for i in range(config["n_epochs"]):
        print("Epoch: {} / {}".format(i + 1, config["n_epochs"]))

        loss_acc_z = 0
        loss_acc_e = 0
        acc_z = 0
        acc_e = 0

        pbar = tqdm.tqdm(dataloader, desc="Batch", dynamic_ncols=True)
        optimizer.zero_grad()
        id = -1
        for j, datum in enumerate(pbar):
            # "idx_batch" -> indices of instances of a class

            embs_tr_batch = datum["train_points"].to(device).float()
            tr_batch = datum["points_to_decode"]
            y = datum["labels"].to(device).long()
            y=y.view(-1,1)
            # np.savetxt('../../output.xyz', embs_tr_batch[0], fmt='%f %f %f')
            # gradient was applied in previous step, so we can reset it now
            if (j - 1) > 0 and (j - 1) % config["aggregation_steps"] == 0:
                optimizer.zero_grad()

            # if not config["use_random_dataloader"]:
            #     b, n_points, coords_num = tr_batch.shape
            #     idx_batch = (
            #         idx_batch.unsqueeze(dim=-1)
            #         .repeat(repeats=(1, n_points))
            #         .reshape((-1,))
            #     )

            num_points_per_object = tr_batch.shape[1]
            # np.savetxt('output.xyz', tr_batch[0], fmt="%f %f %f")
            tr_batch = (
                (
                        tr_batch.float()
                        + 3 * config["x_noise"] * torch.rand(tr_batch.shape)
                )
                .to(device)
                .reshape((-1, 3))
            )
            # np.savetxt('noise.xyz', tr_batch[0], fmt="%f %f %f")
            embs_tr_batch1 = embs_tr_batch.transpose(2, 1)
            w_iter = pointnet(embs_tr_batch1)
            # w_iter = (
            #     w_iter.unsqueeze(dim=1)
            #     .expand(
            #         [w_iter.shape[0], 60, w_iter.shape[-1]]
            #     )
            #     .reshape((-1, w_iter.shape[-1]))
            # )

            e, e_ldetJ = G_flow(w_iter, G_flows, config["n_flows_G"], config["emb_dim"])

            y_batch = (
                y.unsqueeze(dim=1)
                .expand(
                    [y.shape[0], num_points_per_object, y.shape[-1]]
                )
                .reshape((-1, y.shape[-1]))
            )
            e_batch = (
                e.unsqueeze(dim=1)
                .expand(
                    [e.shape[0], num_points_per_object, e.shape[-1]]
                )
                .reshape((-1, e.shape[-1]))
            )
            y_batch = torch.squeeze(y_batch, dim=-1)
            y = torch.squeeze(y, dim=-1)
            z, z_ldetJ = F_flow(tr_batch, e_batch, F_flows, config["n_flows_F"])
            # if pre_train == False:
            #     loss_e = loss_fun_one(e, e_ldetJ, prior_e)

            # get_inv(pointnet, F_flows, G_flows, prior_e, prior_z, test_cloud, device, config, path, means_z)
            logit_e = prior_e.class_logits(e)
            loss_nll_e = F.cross_entropy(logit_e, y)
            logit_z = prior_z.class_logits(z)
            # l_z = []
            # for k in y:
            #     log_z = prior_z.sample((60,), gaussian_id=k)
            #     log_z = prior_z.class_logits(log_z)
            #     l_z.append(log_z)
            # logit_z = torch.cat(l_z, dim=0)
            loss_nll_z = F.cross_entropy(logit_z, y_batch)

            loss_e = loss_fun_cls(e, e_ldetJ, prior_e, y)
            loss_z = loss_fun_cls(z, z_ldetJ, prior_z,y_batch)
            loss = loss_e + loss_nll_e
            loss_acc_z += loss_z.item()
            loss_acc_e += loss_e.item()
            loss_nll_e += loss_nll_e.item()
            loss += loss.item()
            # loss_nll_z += loss_nll_z.item()
            preds_e = torch.argmax(logit_e, dim=1)
            preds_z = torch.argmax(logit_z, dim=1)
            # acc_w+=(preds_w == y).float().mean().item()
            acc_e += (preds_e == y).float().mean().item()
            acc_z += (preds_z == y_batch).float().mean().item()
            # test(pointnet, F_flows, G_flows, prior_e, prior_z, test_dataloader, device, config)
            # z = z.reshape((-1, 600, 3))
            # for k in range(embs_tr_batch.shape[0]):
            #     np.savetxt('output{}.xyz'.format(y[k].item()), z[k].detach().cpu().numpy(), fmt='%f %f %f')
            loss.backward()

            if j > 0 and j % config["aggregation_steps"] == 0:
                optimizer.step()
            # test(pointnet, F_flows, G_flows, prior_e, prior_z, test_dataloader, device, config)
            # train_writer.add_scalar("loss_flow_z", loss_z, global_step=global_step)
            # train_writer.add_scalar("loss_flow_e", loss_e, global_step=global_step)
            # train_writer.add_scalar("loss_nll_e", loss_nll_e, global_step=global_step)
            train_writer.add_scalar("loss", loss, global_step=global_step)
            # train_writer.add_scalar("loss_nll_z", loss_nll_z, global_step=global_step)
            pbar.set_postfix(
                OrderedDict(
                    {
                        # "loss_z_avg": "%.4f" % (loss_acc_z / (j + 1)),
                        # "loss_e_avg": "%.4f" % (loss_acc_e / (j + 1)),
                        # "loss_nll_e": "%.4f" % (loss_nll_e / (j + 1)),
                        # "loss_nll_z": "%.4f" % (loss_nll_z / (j + 1)),
                        "acc_e": "%.4f" % (acc_e / (j + 1)),
                        # "acc_w": "%.4f" % (acc_w / (j + 1)),
                        # "acc_z": "%.4f" % (acc_z/(j+1)),
                        "loss_avg": "%.4f"
                                    % ((loss) / (j + 1)),
                    }
                )
            )

            global_step += 1

        if (loss_acc_e / (j + 1)) < best_e:
            best_e = (loss_acc_e / (j + 1))
            print("---save_best---")
            print('best_acc_e_avg:', best_e)
            path_best = config["save_models_dir"].replace('weight', 'weight_best')
            try:
                for key in F_flows:
                    torch.save(
                        F_flows[key].module.state_dict(),
                        path_best + "F_" + key + ".pth",
                    )
                for key in G_flows:
                    torch.save(
                        G_flows[key].module.state_dict(),
                        path_best + "G_" + key + ".pth",
                    )
            except:
                for key in F_flows:
                    torch.save(
                        F_flows[key].state_dict(), path_best + "F_" + key + ".pth"
                    )
                for key in G_flows:
                    torch.save(
                        G_flows[key].state_dict(), path_best + "G_" + key + ".pth"
                    )

            torch.save(optimizer.state_dict(), path_best + "optimizer.pth")
            torch.save(scheduler.state_dict(), path_best + "scheduler.pth")
            torch.save(pointnet.state_dict(), path_best + "pointnet.pth")
            torch.save({"means_e": means_e, "means_z": means_z}, path_best + "means.pth")
            torch.save(i, path_best + "epoch.pth")
        print("---save---")
        path = config["save_models_dir"]
        try:
            for key in F_flows:
                torch.save(
                    F_flows[key].module.state_dict(),
                    path + "F_" + key + ".pth",
                )
            for key in G_flows:
                torch.save(
                    G_flows[key].module.state_dict(),
                    path + "G_" + key + ".pth",
                )
        except:
            for key in F_flows:
                torch.save(
                    F_flows[key].state_dict(), path + "F_" + key + ".pth"
                )
            for key in G_flows:
                torch.save(
                    G_flows[key].state_dict(), path + "G_" + key + ".pth"
                )

        torch.save(optimizer.state_dict(), path + "optimizer.pth")
        torch.save(scheduler.state_dict(), path + "scheduler.pth")
        torch.save(pointnet.state_dict(), path + "pointnet.pth")
        torch.save({"means_e": means_e, "means_z": means_z}, path + "means.pth")
        torch.save(i, path + "epoch.pth")

        # # sample(F_flows, G_flows, prior_e, prior_z, config["n_flows_F"], i, j, path, means_z, means_e)
        # if j % 2000 == 0 and j > 0:
        #     sample(F_flows, G_flows, prior_e, prior_z, config["n_flows_F"], i, j, path, means_z, means_e, device)

        scheduler.step()
        # sample(F_flows, G_flows, prior_e, prior_z, config["n_flows_F"], i, j, path, means_z, means_e, device)

        # if i % 3 == 0:
        # test(pointnet, F_flows, G_flows, prior_e, prior_z, test_dataloader, device, config)
        # if (i + 1) % 2 == 0:
        #     path = config["save_models_dir_backup"]
        # else:
        #     path = config["save_models_dir"]
        # sample(F_flows, G_flows, prior_e, prior_z, config["n_flows_F"], i, path)
        # try:
        #     for key in F_flows:
        #         torch.save(
        #             F_flows[key].module.state_dict(),
        #             path + "F_" + key + ".pth",
        #         )
        #     for key in G_flows:
        #         torch.save(
        #             G_flows[key].module.state_dict(),
        #             path + "G_" + key + ".pth",
        #         )
        # except:
        #     for key in F_flows:
        #         torch.save(
        #             F_flows[key].state_dict(), path + "F_" + key + ".pth"
        #         )
        #     for key in G_flows:
        #         torch.save(
        #             G_flows[key].state_dict(), path + "G_" + key + ".pth"
        #         )
        #
        # torch.save(optimizer.state_dict(), path + "optimizer.pth")
        # torch.save(scheduler.state_dict(), path + "scheduler.pth")
        # torch.save(pointnet.state_dict(), path + "pointnet.pth")
        # torch.save({"means_e" : means_e, "means_z" : means_z}, path + "means.pth")

        # cov, mmd = metrics_eval(F_flows, config, device)
        #
        # valid_writer.add_scalar(
        #     "loss_z", loss_acc_z / (j + 1), global_step=global_step
        # )
        # valid_writer.add_scalar(
        #     "loss_e", loss_acc_e / (j + 1), global_step=global_step
        # )
        # valid_writer.add_scalar("cov", cov, global_step=global_step)
        # valid_writer.add_scalar("mmd", mmd, global_step=global_step)
    train_writer.close()
    valid_writer.close()


def sample(F_flows, G_flows, prior_e, prior_z, n_flows_F, epoch, step, path, mean_z, mean_e, device):
    for j in range(10):
        e = prior_e.sample((10,), gaussian_id=j)
        # means2 = mean_e[0]
        # e[0] = 0.7 * (e[0] - means2) + means2
        for sample_index in range(2):
            # z = torch.randn(2048, 3).float().to(device)
            z = prior_z.sample((2048,), gaussian_id=j)
            # means1 = mean_z[j].expand(2048, 3)
            # z = 0.7 * (z - means1) + means1
            # np.savetxt(path + 'samples' + '/noise{}_{}_epoch{}_{}.xyz'.format(j, sample_index, epoch, step),
            #            z.cpu().numpy(), fmt='%f %f %f')
            with torch.no_grad():
                targets = torch.LongTensor(2048, 1).fill_(sample_index)
                embeddings4g = e[targets].view(-1, 32)
                z = F_inv_flow(z, embeddings4g, F_flows, n_flows_F)
                if not os.path.exists(path + 'samples'):
                    os.makedirs(path + 'samples')
                np.savetxt(path + 'samples' + '/sample{}_{}_epoch{}_{}.xyz'.format(j, sample_index, epoch, step),
                           z.cpu().numpy(), fmt='%f %f %f')


def test(pointnet, F_flows, G_flows, prior_e, prior_z, test_dataloader, device, config):
    pbar = tqdm.tqdm(test_dataloader, desc="Batch")
    acc_e = 0
    acc_z = 0

    with torch.no_grad():
        for j, datum in enumerate(pbar):
            # "idx_batch" -> indices of instances of a class
            embs_tr_batch = datum["train_points"].to(device)
            tr_batch = datum["points_to_decode"]
            y = datum["labels"]
            y = y.view(-1, 1).to(device).long()
            # np.savetxt('../../output.xyz', embs_tr_batch[0], fmt='%f %f %f')
            # gradient was applied in previous step, so we can reset it now
            num_points_per_object = tr_batch.shape[1]
            tr_batch = (
                (
                    tr_batch.float()
                )
                .to(device)
                .reshape((-1, 3))
            )
            embs_tr_batch = embs_tr_batch.transpose(2, 1)
            w_iter = pointnet(embs_tr_batch)
            # w_iter = (
            #     w_iter.unsqueeze(dim=1)
            #     .expand(
            #         [w_iter.shape[0], num_points_per_object, w_iter.shape[-1]]
            #     )
            #     .reshape((-1, w_iter.shape[-1]))
            # )
            y_batch = (
                y.unsqueeze(dim=1)
                .expand(
                    [y.shape[0], num_points_per_object, y.shape[-1]]
                )
                .reshape((-1, y.shape[-1]))
            ).to(device)
            y_batch = torch.squeeze(y_batch, dim=-1)
            y = torch.squeeze(y, dim=-1)
            e, e_ldetJ = G_flow(w_iter, G_flows, config["n_flows_G"], config["emb_dim"])

            e_batch = (
                e.unsqueeze(dim=1)
                .expand(
                    [e.shape[0], num_points_per_object, e.shape[-1]]
                )
                .reshape((-1, e.shape[-1]))
            )
            z, z_ldetJ = F_flow(tr_batch, e_batch, F_flows, config["n_flows_F"])

            logit_e = prior_e.class_logits(e)
            logit_z = prior_z.class_logits(z)

            preds_e = torch.argmax(logit_e, dim=1)
            preds_z = torch.argmax(logit_z, dim=1)
            acc_e += (preds_e == y).float().mean().item()
            acc_z += (preds_z == y_batch).float().mean().item()

            pbar.set_postfix(
                OrderedDict(
                    {
                        "acc_e": "%.4f" % (acc_e / (j + 1)),
                        "acc_z": "%.4f" % (acc_z / (j + 1))
                    }
                )
            )

def get_means(means,path):
    if not os.path.exists(path + 'samples'):
        os.makedirs(path + 'samples')
    else:
        shutil.rmtree(path + 'samples')
        os.makedirs(path + 'samples')
        print('delete orignal samples')
    np.savetxt(path + 'samples' + '/means.txt'.format('means'), means.cpu().numpy(),
               fmt='%f %f %f')
def get_inv(pointnet, F_flows, G_flows, prior_e, prior_z, dataset, device, config, path, means):
    if not os.path.exists(path + 'samples'):
        os.makedirs(path + 'samples')
    else:
        shutil.rmtree(path + 'samples')
        os.makedirs(path + 'samples')
        print('delete orignal samples')
    samples = []
    tr_idx = np.random.choice(10000, 2048)
    ref_samples = dataset.all_points[:300, tr_idx, :]
    labels = dataset.dataset.all_labels[:300]
    # shuffle_idx = list(range(len(dataset.points_for_point)))
    # random.Random(38383).shuffle(shuffle_idx)
    # all_points = np.array([dataset.points_for_shape[i] for i in shuffle_idx])
    # all_labels = np.array([dataset.labels_for_shape[i] for i in shuffle_idx])
    # tr_idx = np.random.choice(10000, 2048)
    # ref_samples = all_points[:300, :, :3]
    # labels = all_labels[:300]
    # ref_samples = (ref_samples - np.mean(ref_samples, axis=(1, 2), keepdims=True)) / np.std(ref_samples, axis=(1, 2), keepdims=True)
    # ref_samples = torch.from_numpy(ref_samples).float().to(device)
    ref_samples = torch.from_numpy(ref_samples).float().to(device)
    ref_samples = ref_samples.transpose(2, 1)
    # new_ref_samples = ref_samples.transpose(2, 1)
    w = pointnet(ref_samples)
    embs4g = G_flow(w, G_flows, config["n_flows_G"], config["emb_dim"])[0]
    for sample_index in tqdm.trange(300, desc="Sample"):
        z = ref_samples[sample_index]
        with torch.no_grad():
            targets = torch.LongTensor(2048, 1).fill_(sample_index)
            embeddings4g = embs4g[targets].view(-1, config['emb_dim'])
            z = z.transpose(0, 1)
            z1, z_ldetJ = F_flow(z, embeddings4g, F_flows, config["n_flows_F"])
            # np.savetxt(path + 'samples' + '/z{}_{}.xyz'.format(labels[sample_index], sample_index), z1.cpu().numpy(),
            #            fmt='%f %f %f')
            # z = z * std + mean
            # e = encrypt((32), means, embs4g[sample_index], labels[sample_index])
            # e = torch.squeeze(torch.from_numpy(e).to(device), dim=-1)
            # embeddings4g = torch.unsqueeze(e, dim=0)
            # embeddings4g = embeddings4g.expand(2048, 32).float()
            embeddings4g = prior_e.sample((1,), gaussian_id=labels[sample_index][0])
            embeddings4g = embeddings4g.expand(2048, 32).float()
            # z = encrypt((2048*3), means, z, labels[sample_index])
            # z = torch.squeeze(torch.from_numpy(z).to(device), dim=-1)
            means1 = means[labels[sample_index][0]].expand(2048, 3)
            A = np.random.rand(2048 * 3, 2048 * 3)
            A, R = np.linalg.qr(A)
            A = torch.tensor(A).float().to(device)
            z2 = torch.reshape((z1 - means1), (2048 * 3, 1))
            # z2 = torch.matmul(A, z2)
            z2 = torch.reshape(z2, (2048, 3))
            z3 = z2 * 0.7 + means1
            np.savetxt(path + 'samples' + '/inv_{}_{}.txt'.format(labels[sample_index][0], sample_index), z1.cpu().numpy(),
                       fmt='%f %f %f')
            z4 = F_inv_flow(z1, embeddings4g, F_flows, config['n_flows_F'])
            np.savetxt(path + 'samples' + '/enr_{}_{}.txt'.format(labels[sample_index][0], sample_index), z4.cpu().numpy(),
                       fmt='%f %f %f')
            np.savetxt(path + 'samples' + '/ref_{}_{}.txt'.format(labels[sample_index][0], sample_index), z.cpu().numpy(),
                       fmt='%f %f %f')


def encrypt(shape, means, samples, gussin_id):
    num = np.prod(shape)
    A = np.random.rand(num, num)
    A, R = np.linalg.qr(A)
    means = np.squeeze(means[gussin_id].cpu().numpy(), axis=0)
    means = np.expand_dims(means, axis=-1)
    b = means - A @ means
    samples = np.expand_dims(samples.cpu().numpy(), axis=-1)
    samples = A @ samples + b
    return samples


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("-c", "--config", type=str, default='../../configs/cif_train_cls_new.yaml')

    args = parser.parse_args()

    if not args.config:
        parser.print_help()
    else:
        with open(args.config) as f:
            main(yaml.full_load(f))
