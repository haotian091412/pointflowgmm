import argparse
import datetime
import yaml
import os
import sys
import shutil

parent_path = os.path.dirname(os.path.dirname(os.path.abspath(os.path.dirname(__file__))))

sys.path.append(parent_path)

os.environ["CUDA_VISIBLE_DEVICES"] = "0"
import tqdm
from collections import OrderedDict
# import open3d as o3d
import torch
from torch import distributions
from torch.utils.data import *

import numpy as np
from torch.nn import functional as F
from data.datasets_pointflow_ModelNet import (
#     CIFDatasetDecorator,
    ModelNet40PointClouds,
    CIFDatasetDecoratorMultiObject,
)
from data.datasets_pointflow_Modelnet_new import (
    ModelNet
)

# from data.datasets_Pointflow_IntrA import (
#     CIFDatasetDecorator,
#     IntrAPointCloud,
#     CIFDatasetDecoratorMultiObject,
# )
from utils.losses import loss_fun, loss_fun_gmm, loss_fun_one

from models.models_normalizing_rotate import  model_init_pointnet
from models.flows import F_flow, G_flow
from models.pointnet import Encoder
from models.pointnet2_model import Pointnet2
from models.normalizing_rotate_distribution import SSLGaussMixture
from models.flow_loss import FlowLoss
# from experiments.test.metrics_eval import metrics_eval
from models.flows import F_inv_flow
from models.matrixs import Matrix
from utils.model_utils import *
from torch.utils.tensorboard import SummaryWriter
from scipy.stats import ortho_group
import random
from models.cosine_loss import cosine_loss
from models.rotate_matrix import MLP


def main(config: argparse.Namespace):
    if config['distributed'] == False:
        local_rank = 0
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    else:
        local_rank = int(os.environ['LOCAL_RANK'])
        torch.distributed.init_process_group(backend='nccl', world_size=torch.cuda.device_count(), rank=args.local_rank)
        # torch.cuda.set_device(args.local_rank)
        # device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        device = torch.device('cuda', local_rank)

    n_means = 10  # 组数
    n_dim_z = 3  # 维数

    # 随机生成第一组均值
    means_z = np.random.randn(n_dim_z).reshape(1, -1)

    # 生成其余组均值
    while means_z.shape[0] < n_means:
        new_mean = 3.0 * np.random.randn(n_dim_z).reshape(1, -1)
        dists = np.linalg.norm(means_z - new_mean, axis=1)
        if np.min(dists) >= 6:
            means_z = np.vstack((means_z, new_mean))
    means_z = torch.from_numpy(means_z).to(device).float()
    prior_gmm = SSLGaussMixture(means_z, device=device)

    prior_z = distributions.MultivariateNormal(
        torch.zeros(3), torch.eye(3)
    )

    # Matrix=MLP(input_dim=1, output_dim=9, hidden_dim1=3,hidden_dim2=32,hidden_dim3=64).to(device)

    if config["use_random_dataloader"]:
        batch_size = config["batch_size_if_random_split"]
    else:
        batch_size = config["batch_size"]


    if config["load_models"]:
        F_flows, G_flows, optimizer, scheduler, pointnet = model_load_pointnet(config, device, pointnet)
        means = torch.load(config["load_models_dir"] + "weight/" + "means.pth")
        means_z = means['means_z']
        means_e = means['means_e']
        prior_e = SSLGaussMixture(means_e, device=device)
        prior_z = SSLGaussMixture(means_z, device=device)

    else:
        F_flows, Matrix_list, optimizer, scheduler = model_init_pointnet(config, device,prior_gmm, local_rank)

    processed_data = ModelNet(config)

    if config["distributed"] == True:
        train_sampler = DistributedSampler(processed_data)
        dataloader = DataLoader(
            processed_data, batch_size=batch_size, shuffle=False, sampler=train_sampler
        )
    else:
        train_sampler = None
        dataloader = DataLoader(
            processed_data, batch_size=batch_size, shuffle=True
        )
    train(F_flows, Matrix_list, optimizer, scheduler, dataloader, device, config, prior_z, prior_gmm,
          train_sampler, local_rank)


def train(F_flows, Matrix_list, optimizer, scheduler, dataloader, device, config, prior_z,prior_z_rotated,train_sampler, local_rank):
    for key in F_flows:
        F_flows[key].train()
    for key in Matrix_list:
        Matrix_list[key].train()

    train_writer = SummaryWriter(config["tensorboard_dir"] + "train")

    global_step = 0
    for i in range(config["n_epochs"]):
        print("Epoch: {} / {}".format(i + 1, config["n_epochs"]))
        if config["distributed"]==True:
            train_sampler.set_epoch(i)

        loss_acc_z = 0

        acc_z = 0
        pbar = tqdm.tqdm(dataloader, desc="Batch", dynamic_ncols=True)
        optimizer.zero_grad()
        for j, datum in enumerate(pbar):
            tr_batch = datum["points_to_decode"]
            y = datum["labels"]
            num_points_per_object = tr_batch.shape[1]
            tr_batch = (
                (
                        tr_batch.float()
                )
                .to(device)
                .reshape((-1, 3))
            )


            z, z_ldetJ = F_flow(tr_batch, None, F_flows, config["n_flows_F"])
            z_cos = z.reshape(y.shape[0], num_points_per_object, -1)
            cos_loss = cosine_loss(z_cos,device)

            loss_z=loss_fun_one(z,z_ldetJ,prior_z)

            # cos_loss = cosine_loss(z_cos).to(device)
            loss=loss_z+0.01*cos_loss

            loss.backward()
            if j > 0 and j % config["aggregation_steps"] == 0:
                optimizer.step()
                scheduler.step()
            loss = loss.item()

            train_writer.add_scalar("loss", loss, global_step=global_step)
            pbar.set_postfix(
                OrderedDict(
                    {
                        "loss_avg": "%.4f"
                                    % (loss)
                    }
                )
            )

    for i in range(config["n_epochs"]):
        print("Epoch: {} / {}".format(i + 1, config["n_epochs"]))
        if config["distributed"]==True:
            train_sampler.set_epoch(i)

        loss_acc_z = 0

        acc_z = 0
        pbar = tqdm.tqdm(dataloader, desc="Batch", dynamic_ncols=True)
        optimizer.zero_grad()
        for j, datum in enumerate(pbar):

            if (j - 1) > 0 and (j - 1) % config["aggregation_steps"] == 0:
                optimizer.zero_grad()
            tr_batch = datum["points_to_decode"]
            num_points_per_object = tr_batch.shape[1]
            tr_batch = (
                (
                        tr_batch.float()
                        + 3 * config["x_noise"] * torch.rand(tr_batch.shape)
                )
                .to(device)
                .reshape((-1, 3))
            )
            y = datum["labels"]
            y = y.view(-1, 1)
            y_batch = (
                y.unsqueeze(dim=1)
                .expand(
                    [y.shape[0], num_points_per_object, y.shape[-1]]
                )
                .reshape((-1, y.shape[-1]))
            )
            y_matrix = y_batch.to(device).float()
            y_batch = torch.squeeze(y_batch, dim=-1).to(device).long()

            # z, z_ldetJ = F_flow(tr_batch, None, F_flows, config["n_flows_F"])
            z_rotated,loss_matrix=Matrix(y_matrix,tr_batch,Matrix_list)



            logit_z = prior_z_rotated.class_logits(z_rotated)

            # loss_z=loss_fun_one(z,z_ldetJ,prior_z)
            loss_nll_z = F.cross_entropy(logit_z, y_batch)
            loss=loss_nll_z


            loss.backward()
            if j > 0 and j % config["aggregation_steps"] == 0:
                optimizer.step()
                scheduler.step()

            preds_z = torch.argmax(logit_z, dim=1)
            acc_z += (preds_z == y_batch).float().mean().item()
            loss_acc_z+=loss_matrix.item()
            pbar.set_postfix(
                OrderedDict(
                    {
                        "acc": "%.4f" % (acc_z / (j + 1)),
                        "loss": "%.4f" % (loss_acc_z / (j + 1)),
                    }
                )
            )



def Rotate(z,matrix):

    z_rotate=None
    for i in range(z.shape[0]):
        matrix_rotate=matrix[i].reshape(3,3)
        z_single=z[i].reshape(3,1)
        z_single_rotate=torch.matmul( matrix_rotate,z_single)
        if i==0:
            z_rotate=z_single_rotate
        else:
            z_rotate=torch.cat((z_rotate,z_single_rotate),1)
    return z_rotate.transpose(0,1)

def Loss_matrix(matrix):
    loss_matrix=torch.tensor(0.0)
    l2=torch.nn.MSELoss()
    for single_matrix in matrix:
        single_matrix=single_matrix.reshape(3,3)
        mat_diff = torch.matmul(single_matrix, single_matrix.transpose(0,1))
        I = torch.eye(single_matrix.shape[0])
        mat_diff_loss=l2(mat_diff,I)
        loss_matrix += mat_diff_loss
    return torch.mean(loss_matrix)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("-c", "--config", type=str, default='../../configs/cif_train_cls_new.yaml')


    args = parser.parse_args()

    if not args.config:
        parser.print_help()
    else:
        with open(args.config) as f:
            main(yaml.full_load(f))