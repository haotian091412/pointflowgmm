import argparse
import datetime
import yaml
import os
import sys
import shutil
from pingouin import multivariate_normality
parent_path = os.path.dirname(os.path.dirname(os.path.abspath(os.path.dirname(__file__))))

sys.path.append(parent_path)

os.environ["CUDA_VISIBLE_DEVICES"] = "0,1,2"
import tqdm
from collections import OrderedDict
# import open3d as o3d
import torch
from torch import distributions
from torch.utils.data import *

import numpy as np
from torch.nn import functional as F
from data.datasets_pointflow_ModelNet import (
#     CIFDatasetDecorator,
    ModelNet40PointClouds,
    CIFDatasetDecoratorMultiObject,
)
from data.datasets_pointflow_ScanObjectNN import (
    ScanObjectNNDatasetH5
)

# from data.datasets_Pointflow_IntrA import (
#     CIFDatasetDecorator,
#     IntrAPointCloud,
#     CIFDatasetDecoratorMultiObject,
# )
from utils.losses import loss_fun, loss_fun_gmm, loss_fun_one

from models.models import model_init, model_load, model_init_pointnet, model_load_pointnet
from models.flows import F_flow, G_flow
from models.pointnet import Encoder
from models.pointnet2_model import Pointnet2
from models.distributions import SSLGaussMixture
from models.flow_loss import FlowLoss
# from experiments.test.metrics_eval import metrics_eval
from models.flows import F_inv_flow
from utils.model_utils import *
from torch.utils.tensorboard import SummaryWriter
from scipy.stats import ortho_group
import random
from models.cosine_loss import cosine_loss


def get_mean(shape=(32), r=1, num_means=2, device=None):
    D = np.prod(shape)
    means = torch.zeros((num_means, D)).to(device)
    for i in range(num_means):
        means[i] = r * torch.randn(D)
    return means


def main(config: argparse.Namespace):

    if config['distributed']==False:
       local_rank = 0
       device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    else:
        local_rank=int(os.environ['LOCAL_RANK'])
        torch.distributed.init_process_group(backend='nccl', world_size=torch.cuda.device_count(), rank=local_rank)
        # torch.cuda.set_device(args.local_rank)
        # device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        device = torch.device('cuda', local_rank)



    n_means = 15  # 组数
    n_dim_z = 3  # 维数

    # 随机生成第一组均值
    means_z = np.random.randn(n_dim_z).reshape(1, -1)

    # 生成其余组均值
    while means_z.shape[0] < n_means:
        new_mean = 6.0 * np.random.randn(n_dim_z).reshape(1, -1)
        dists = np.linalg.norm(means_z - new_mean, axis=1)
        if np.min(dists) >= 6:
            means_z = np.vstack((means_z, new_mean))
    means_z = torch.from_numpy(means_z).to(device).float()
    n_means = 15  # 组数
    n_dim_e = config["emb_dim"]  # 维数

    # 随机生成第一组均值
    means_e = np.random.randn(n_dim_e).reshape(1, -1)

    # 生成其余组均值
    while means_e.shape[0] < n_means:
        new_mean = 12.0 * np.random.randn(n_dim_e).reshape(1, -1)
        dists = np.linalg.norm(means_e - new_mean, axis=1)
        if np.min(dists) >= 12:
            means_e = np.vstack((means_e, new_mean))
    means_e = torch.from_numpy(means_e).to(device).float()
    if config['distributed']==True:
        torch.distributed.broadcast(means_e, src=0)
        torch.distributed.all_reduce(means_e, op=torch.distributed.ReduceOp.SUM)
        torch.distributed.broadcast(means_z, src=0)
        torch.distributed.all_reduce(means_z, op=torch.distributed.ReduceOp.SUM)

    prior_e = SSLGaussMixture(means_e, device=device)
    prior_z = SSLGaussMixture(means_z, device=device)
    # prior_e = distributions.MultivariateNormal(
    #     torch.zeros(32), torch.eye(32)
    # )
    # prior_z = distributions.MultivariateNormal(
    #     torch.zeros(3), torch.eye(3)
    # )

    Ae, Az = torch.tensor(ortho_group.rvs(dim=config['emb_dim'])).to(device).float(), torch.tensor(
        ortho_group.rvs(dim=3)).to(device).float()
    # for i in range(40):
    #     z = prior_z.sample((2048,), gaussian_id=i)
    #     np.savetxt('output{}.xyz'.format(i), z.cpu().numpy(), fmt='%f %f %f')
    # prior_z = distributions.MultivariateNormal(
    #     torch.zeros(3), torch.eye(3)
    # )
    # prior_e = distributions.MultivariateNormal(
    #     torch.zeros(config["emb_dim"]), torch.eye(config["emb_dim"])
    # )

    if config["use_random_dataloader"]:
        batch_size = config["batch_size_if_random_split"]
    else:
        batch_size = config["batch_size"]


    pointnet = Pointnet2(
        emb_dim=config["emb_dim"],
        normal_channel=False
    ).to(device)

    if config["load_models"]:
        F_flows, G_flows, optimizer, scheduler, pointnet = model_load_pointnet(config, device, pointnet)
        means = torch.load(config["load_models_dir"] + "/weight/" + "means.pth")
        means_z = means['means_z'].to(device)
        means_e = means['means_e'].to(device)
        prior_e = SSLGaussMixture(means_e, device=device)
        prior_z = SSLGaussMixture(means_z, device=device)
        # A = torch.load(config["load_models_dir"] + "weight/" + "A.pth")
        # Ae = A['Ae']
        # Az = A['Az']

    else:
        F_flows, G_flows, optimizer,scheduler,pointnet = model_init_pointnet(config, device, pointnet,local_rank)

    processed_data = ScanObjectNNDatasetH5(config)
    if config["distributed"]==True:
        train_sampler = DistributedSampler(processed_data)
        dataloader = DataLoader(
            processed_data, batch_size=batch_size, shuffle=False, sampler=train_sampler
        )
    else:
        train_sampler = None
        dataloader = DataLoader(
            processed_data, batch_size=batch_size, shuffle=True
        )


    if config['subset'] == 'train':
        print('start training')
        if config['get_inv'] == True:
            get_means(means_z,config['save_samples_dir'])
            get_inv(pointnet, F_flows, G_flows, prior_e, prior_z, processed_data, device, config,
                    config['save_samples_dir'], means_z)
        else:
            # optimizer = optim(G_flows,F_flows, config['l_rate'], pointnet)
            train(F_flows, G_flows, optimizer, scheduler, pointnet, dataloader, device, config, prior_e, prior_z,
                  means_e, means_z,train_sampler,local_rank)

    elif config['subset'] == 'test':
        print('start testing')
        if config['get_inv'] == True:
            get_inv(pointnet, F_flows, G_flows, prior_e, prior_z, processed_data, device, config,
                    config['save_samples_dir'], means_z)
        else:
            test(pointnet, F_flows, G_flows, prior_e, prior_z, dataloader, device, config)


    else:
        print('please choose the subset')


def train(F_flows, G_flows, optimizer, scheduler, pointnet, dataloader, device, config, prior_e, prior_z, means_e,
          means_z,train_sampler,local_rank):
    for key in F_flows:
        F_flows[key].train()

    for key in G_flows:
        G_flows[key].train()
    pointnet.train()

    train_writer = SummaryWriter(config["tensorboard_dir"] + "train")
    valid_writer = SummaryWriter(config["tensorboard_dir"] + "valid")

    global_step = 0
    best_e = 0

    for i in range(config["n_epochs"]):
        print("Epoch: {} / {}".format(i + 1, config["n_epochs"]))
        if config["distributed"]==True:
            train_sampler.set_epoch(i)

        loss_acc_z = 0
        loss_acc_e = 0
        loss_acc_w=0
        acc_z = 0
        acc_e = 0
        acc_w = 0

        pbar = tqdm.tqdm(dataloader, desc="Batch", dynamic_ncols=True)
        optimizer.zero_grad()
        id = -1
        for j, datum in enumerate(pbar):
            # "idx_batch" -> indices of instances of a class

            embs_tr_batch = datum["train_points"].to(device).float()
            tr_batch = datum["points_to_decode"]
            y = datum["labels"].to(device).long()
            y=y.view(-1,1)
            # np.savetxt('../../output.xyz', embs_tr_batch[0], fmt='%f %f %f')
            # gradient was applied in previous step, so we can reset it now
            if (j - 1) > 0 and (j - 1) % config["aggregation_steps"] == 0:
                optimizer.zero_grad()

            # if not config["use_random_dataloader"]:
            #     b, n_points, coords_num = tr_batch.shape
            #     idx_batch = (
            #         idx_batch.unsqueeze(dim=-1)
            #         .repeat(repeats=(1, n_points))
            #         .reshape((-1,))
            #     )

            num_points_per_object = tr_batch.shape[1]
            # np.savetxt('output.xyz', tr_batch[0], fmt="%f %f %f")
            tr_batch = (
                (
                        tr_batch.float()
                        + 3 * config["x_noise"] * torch.rand(tr_batch.shape)
                )
                .to(device)
                .reshape((-1, 3))
            )
            # np.savetxt('noise.xyz', tr_batch[0], fmt="%f %f %f")
            embs_tr_batch1 = embs_tr_batch.transpose(2, 1)
            w_iter = pointnet(embs_tr_batch1)
            # w_batch = (
            #     w_iter.unsqueeze(dim=1)
            #     .expand(
            #         [w_iter.shape[0], 60, w_iter.shape[-1]]
            #     )
            #     .reshape((-1, w_iter.shape[-1]))
            # )

            e, e_ldetJ = G_flow(w_iter, G_flows, config["n_flows_G"], config["emb_dim"])

            y_batch = (
                y.unsqueeze(dim=1)
                .expand(
                    [y.shape[0], num_points_per_object, y.shape[-1]]
                )
                .reshape((-1, y.shape[-1]))
            )
            e_batch = (
                e.unsqueeze(dim=1)
                .expand(
                    [e.shape[0], num_points_per_object, e.shape[-1]]
                )
                .reshape((-1, e.shape[-1]))
            )
            y_batch = torch.squeeze(y_batch, dim=-1)
            y = torch.squeeze(y, dim=-1)
            z, z_ldetJ = F_flow(tr_batch, e_batch, F_flows, config["n_flows_F"])
            z_cos=z.reshape(e.shape[0],num_points_per_object, -1)
            cos_loss=cosine_loss(z_cos,device)
            # if pre_train == False:
            #     loss_e = loss_fun_one(e, e_ldetJ, prior_e)

            # get_inv(pointnet, F_flows, G_flows, prior_e, prior_z, test_cloud, device, config, path, means_z)
            logit_e = prior_e.class_logits(e)
            # loss_nll_e = F.cross_entropy(logit_e, y)


            logit_z = prior_z.class_logits(z)
            # l_z = []
            # for k in y:
            #     log_z = prior_z.sample((60,), gaussian_id=k)
            #     log_z = prior_z.class_logits(log_z)
            #     l_z.append(log_z)
            # logit_z = torch.cat(l_z, dim=0)
            # loss_nll_z = F.cross_entropy(logit_z, y_batch)
            loss_e = loss_fun_gmm(e, e_ldetJ, prior_e, y)
            loss_z = loss_fun_gmm(z, z_ldetJ, prior_z, y_batch)
            loss = loss_e + loss_z + cos_loss
            loss_acc_z += loss_z.item()
            loss_acc_e += loss_e.item()
            # loss_acc_e += loss_e.item()
            # loss_nll_e += loss_nll_e.item()
            loss += loss.item()
            # loss_nll_z += loss_nll_z.item()
            # preds_e = torch.argmax(logit_e, dim=1)
            preds_e = torch.argmax(logit_e, dim=-1)
            preds_z = torch.argmax(logit_z, dim=1)
            acc_e+=(preds_e == y).float().mean().item()
            # acc_e += (preds_e == y).float().mean().item()
            acc_z += (preds_z == y_batch).float().mean().item()
            # test(pointnet, F_flows, G_flows, prior_e, prior_z, test_dataloader, device, config)
            # z = z.reshape((-1, 600, 3))
            # for k in range(embs_tr_batch.shape[0]):
            #     np.savetxt('output{}.xyz'.format(y[k].item()), z[k].detach().cpu().numpy(), fmt='%f %f %f')
            loss.backward()
            # scheduler.step()

            if j > 0 and j % config["aggregation_steps"] == 0:
                optimizer.step()
                scheduler.step()
            # test(pointnet, F_flows, G_flows, prior_e, prior_z, test_dataloader, device, config)
            # train_writer.add_scalar("loss_flow_z", loss_z, global_step=global_step)
            # train_writer.add_scalar("loss_flow_e", loss_e, global_step=global_step)
            # train_writer.add_scalar("loss_nll_e", loss_nll_e, global_step=global_step)
            train_writer.add_scalar("loss", loss, global_step=global_step)
            # train_writer.add_scalar("loss_nll_z", loss_nll_z, global_step=global_step)
            pbar.set_postfix(
                OrderedDict(
                    {
                        # "loss_z_avg": "%.4f" % (loss_acc_z / (j + 1)),
                        # "loss_e_avg": "%.4f" % (loss_acc_e / (j + 1)),
                        # "loss_nll_e": "%.4f" % (loss_nll_e / (j + 1)),
                        # "loss_nll_z": "%.4f" % (loss_nll_z / (j + 1)),
                        "acc_e": "%.4f" % (acc_e / (j + 1)),
                        # "acc_e": "%.4f" % (acc_e / (j + 1)),
                        "acc_z": "%.4f" % (acc_z / (j + 1)),
                        # "loss_avg": "%.4f"
                        #             % ((loss) / (j + 1)),
                    }
                )
            )

            global_step += 1
            if j % 800 == 0 and j > 0 and local_rank == 0:

                print("---save---")
                path = config["save_models_dir"]
                try:
                    for key in F_flows:
                        torch.save(
                            F_flows[key].module.state_dict(),
                            path + "F_" + key + ".pth",
                        )
                    for key in G_flows:
                        torch.save(
                            G_flows[key].module.state_dict(),
                            path + "G_" + key + ".pth",
                        )
                    torch.save(pointnet.module.state_dict(), path + "pointnet.pth")
                except:
                    for key in F_flows:
                        torch.save(
                            F_flows[key].state_dict(), path + "F_" + key + ".pth"
                        )
                    for key in G_flows:
                        torch.save(
                            G_flows[key].state_dict(), path + "G_" + key + ".pth"
                        )
                    torch.save(pointnet.state_dict(), path + "pointnet.pth")

                torch.save(optimizer.state_dict(), path + "optimizer.pth")
                torch.save(scheduler.state_dict(), path + "scheduler.pth")
                torch.save({"means_e": means_e, "means_z": means_z}, path + "means.pth")
                torch.save(i, path + "epoch.pth")




        if (loss_acc_e / (j + 1)) < best_e:
            best_e = (loss_acc_e / (j + 1))
            print("---save_best---")
            print('best_acc_e_avg:', best_e)
            path_best = config["save_models_dir"].replace('weight', 'weight_best')
            try:
                for key in F_flows:
                    torch.save(
                        F_flows[key].module.state_dict(),
                        path_best + "F_" + key + ".pth",
                    )
                for key in G_flows:
                    torch.save(
                        G_flows[key].module.state_dict(),
                        path_best + "G_" + key + ".pth",
                    )
            except:
                for key in F_flows:
                    torch.save(
                        F_flows[key].state_dict(), path_best + "F_" + key + ".pth"
                    )
                for key in G_flows:
                    torch.save(
                        G_flows[key].state_dict(), path_best + "G_" + key + ".pth"
                    )

            torch.save(optimizer.state_dict(), path_best + "optimizer.pth")
            torch.save(scheduler.state_dict(), path_best + "scheduler.pth")
            torch.save(pointnet.state_dict(), path_best + "pointnet.pth")
            torch.save({"means_e": means_e, "means_z": means_z}, path_best + "means.pth")
            torch.save(i, path_best + "epoch.pth")
        if local_rank == 0:
            print("---save---")
            path = config["save_models_dir"]
            try:
                for key in F_flows:
                    torch.save(
                        F_flows[key].module.state_dict(),
                        path + "F_" + key + ".pth",
                    )
                for key in G_flows:
                    torch.save(
                        G_flows[key].module.state_dict(),
                        path + "G_" + key + ".pth",
                    )
                torch.save(pointnet.module.state_dict(), path + "pointnet.pth")
            except:
                for key in F_flows:
                    torch.save(
                        F_flows[key].state_dict(), path + "F_" + key + ".pth"
                    )
                for key in G_flows:
                    torch.save(
                        G_flows[key].state_dict(), path + "G_" + key + ".pth"
                    )
                torch.save(pointnet.state_dict(), path + "pointnet.pth")

            torch.save(optimizer.state_dict(), path + "optimizer.pth")
            torch.save(scheduler.state_dict(), path + "scheduler.pth")
            torch.save({"means_e": means_e, "means_z": means_z}, path + "means.pth")
            torch.save(i, path + "epoch.pth")

        # # sample(F_flows, G_flows, prior_e, prior_z, config["n_flows_F"], i, j, path, means_z, means_e)
        # if j % 2000 == 0 and j > 0:
        #     sample(F_flows, G_flows, prior_e, prior_z, config["n_flows_F"], i, j, path, means_z, means_e, device)


        # sample(F_flows, G_flows, prior_e, prior_z, config["n_flows_F"], i, j, path, means_z, means_e, device)

        # if i % 3 == 0:
        # test(pointnet, F_flows, G_flows, prior_e, prior_z, test_dataloader, device, config)
        # if (i + 1) % 2 == 0:
        #     path = config["save_models_dir_backup"]
        # else:
        #     path = config["save_models_dir"]
        # sample(F_flows, G_flows, prior_e, prior_z, config["n_flows_F"], i, path)
        # try:
        #     for key in F_flows:
        #         torch.save(
        #             F_flows[key].module.state_dict(),
        #             path + "F_" + key + ".pth",
        #         )
        #     for key in G_flows:
        #         torch.save(
        #             G_flows[key].module.state_dict(),
        #             path + "G_" + key + ".pth",
        #         )
        # except:
        #     for key in F_flows:
        #         torch.save(
        #             F_flows[key].state_dict(), path + "F_" + key + ".pth"
        #         )
        #     for key in G_flows:
        #         torch.save(
        #             G_flows[key].state_dict(), path + "G_" + key + ".pth"
        #         )
        #
        # torch.save(optimizer.state_dict(), path + "optimizer.pth")
        # torch.save(scheduler.state_dict(), path + "scheduler.pth")
        # torch.save(pointnet.state_dict(), path + "pointnet.pth")
        # torch.save({"means_e" : means_e, "means_z" : means_z}, path + "means.pth")

        # cov, mmd = metrics_eval(F_flows, config, device)
        #
        # valid_writer.add_scalar(
        #     "loss_z", loss_acc_z / (j + 1), global_step=global_step
        # )
        # valid_writer.add_scalar(
        #     "loss_e", loss_acc_e / (j + 1), global_step=global_step
        # )
        # valid_writer.add_scalar("cov", cov, global_step=global_step)
        # valid_writer.add_scalar("mmd", mmd, global_step=global_step)
    train_writer.close()
    valid_writer.close()


def sample(F_flows, G_flows, prior_e, prior_z, n_flows_F, epoch, step, path, mean_z, mean_e, device):
    for j in range(10):
        e = prior_e.sample((10,), gaussian_id=j)
        # means2 = mean_e[0]
        # e[0] = 0.7 * (e[0] - means2) + means2
        for sample_index in range(2):
            # z = torch.randn(2048, 3).float().to(device)
            z = prior_z.sample((2048,), gaussian_id=j)
            # means1 = mean_z[j].expand(2048, 3)
            # z = 0.7 * (z - means1) + means1
            # np.savetxt(path + 'samples' + '/noise{}_{}_epoch{}_{}.xyz'.format(j, sample_index, epoch, step),
            #            z.cpu().numpy(), fmt='%f %f %f')
            with torch.no_grad():
                targets = torch.LongTensor(2048, 1).fill_(sample_index)
                embeddings4g = e[targets].view(-1, 32)
                z = F_inv_flow(z, embeddings4g, F_flows, n_flows_F)
                if not os.path.exists(path + 'samples'):
                    os.makedirs(path + 'samples')
                np.savetxt(path + 'samples' + '/sample{}_{}_epoch{}_{}.xyz'.format(j, sample_index, epoch, step),
                           z.cpu().numpy(), fmt='%f %f %f')


def test(pointnet, F_flows, G_flows, prior_e, prior_z, test_dataloader, device, config):
    pbar = tqdm.tqdm(test_dataloader, desc="Batch")
    acc_e = 0
    acc_z = 0
    loss_acc_z=0

    with torch.no_grad():
        for j, datum in enumerate(pbar):
            # "idx_batch" -> indices of instances of a class
            embs_tr_batch = datum["train_points"].to(device)
            tr_batch = datum["points_to_decode"]
            y = datum["labels"]
            y = y.view(-1, 1).to(device).long()
            # np.savetxt('../../output.xyz', embs_tr_batch[0], fmt='%f %f %f')
            # gradient was applied in previous step, so we can reset it now
            num_points_per_object = tr_batch.shape[1]
            tr_batch = (
                (
                    tr_batch.float()
                )
                .to(device)
                .reshape((-1, 3))
            )
            embs_tr_batch = embs_tr_batch.transpose(2, 1)
            w_iter = pointnet(embs_tr_batch)
            # w_iter = (
            #     w_iter.unsqueeze(dim=1)
            #     .expand(
            #         [w_iter.shape[0], num_points_per_object, w_iter.shape[-1]]
            #     )
            #     .reshape((-1, w_iter.shape[-1]))
            # )
            y_batch = (
                y.unsqueeze(dim=1)
                .expand(
                    [y.shape[0], num_points_per_object, y.shape[-1]]
                )
                .reshape((-1, y.shape[-1]))
            ).to(device)
            y_batch = torch.squeeze(y_batch, dim=-1)
            y = torch.squeeze(y, dim=-1)
            e, e_ldetJ = G_flow(w_iter, G_flows, config["n_flows_G"], config["emb_dim"])

            e_batch = (
                e.unsqueeze(dim=1)
                .expand(
                    [e.shape[0], num_points_per_object, e.shape[-1]]
                )
                .reshape((-1, e.shape[-1]))
            )
            z, z_ldetJ = F_flow(tr_batch, e_batch, F_flows, config["n_flows_F"])

            logit_e = prior_e.class_logits(e)
            logit_z = prior_z.class_logits(z)
            loss_z = loss_fun_gmm(z, z_ldetJ, prior_z, y_batch)

            preds_e = torch.argmax(logit_e, dim=1)
            preds_z = torch.argmax(logit_z, dim=1)
            acc_e += (preds_e == y).float().mean().item()
            acc_z += (preds_z == y_batch).float().mean().item()
            loss_acc_z+=loss_z.item()

            pbar.set_postfix(
                OrderedDict(
                    {
                        "acc_e": "%.4f" % (acc_e / (j + 1)),
                        "acc_z": "%.4f" % (acc_z / (j + 1))
                    }
                )
            )

def get_means(means,path):
    if not os.path.exists(path + 'samples'):
        os.makedirs(path + 'samples')
    else:
        shutil.rmtree(path + 'samples')
        os.makedirs(path + 'samples')
        print('delete orignal samples')
    np.savetxt(path + 'samples' + '/means.txt'.format('means'), means.cpu().numpy(),
               fmt='%f %f %f')
def get_inv(pointnet, F_flows, G_flows, prior_e, prior_z, dataset, device, config, path, means_z):
    if not os.path.exists(path + 'samples'):
        os.makedirs(path + 'samples')
    else:
        shutil.rmtree(path + 'samples')
        os.makedirs(path + 'samples')
        print('delete orignal samples')
    samples = []
    # tr_idx = np.random.choice(10000, 2048)
    # ref_samples = dataset.all_points[:300, tr_idx, :]
    # labels = dataset.dataset.all_labels[:300]
    shuffle_idx = list(range(len(dataset.data)))
    random.Random(38383).shuffle(shuffle_idx)
    all_points = np.array([dataset.data[i] for i in shuffle_idx])
    all_labels = np.array([dataset.labels[i] for i in shuffle_idx])
    ref_samples = all_points[:300, :, :3]
    labels = all_labels[:300]
    # ref_samples = (ref_samples - np.mean(ref_samples, axis=(1, 2), keepdims=True)) / np.std(ref_samples, axis=(1, 2), keepdims=True)
    # ref_samples = torch.from_numpy(ref_samples).float().to(device)
    ref_samples = torch.from_numpy(ref_samples).float().to(device)
    ref_samples = ref_samples.transpose(2, 1)
    A = np.random.rand(2048 * 3, 2048 * 3)
    A, R = np.linalg.qr(A)
    A = torch.tensor(A).float().to(device)
    # new_ref_samples = ref_samples.transpose(2, 1)
    w = pointnet(ref_samples)
    sum_p=0
    embs4g,e_idetj = G_flow(w, G_flows, config["n_flows_G"], config["emb_dim"])
    for sample_index in tqdm.trange(300, desc="Sample"):
        z = ref_samples[sample_index]
        with torch.no_grad():
            targets = torch.LongTensor(2048, 1).fill_(sample_index)
            embeddings4g = embs4g[targets].view(-1, config['emb_dim'])
            z = z.transpose(0, 1)
            z1, z_ldetJ = F_flow(z, embeddings4g, F_flows, config["n_flows_F"])
            batch_size = int(z1.shape[0] / 2048)
            translation = means_z[labels[sample_index]].expand(2048, 3)
            z1 = z1.reshape(batch_size, 2048, 3)
            z1 = z1 - translation
            z2 = torch.reshape(z1, (-1, 2048 * 3, 1))
            z2 = torch.matmul(A, z2)
            # z2= torch.matmul(A1, z2)
            z2 = torch.reshape(z2, (batch_size, 2048, 3))[0]
            # z2= z2 + translation

            # Convert tensor to numpy array for scipy
            data_numpy = z2.cpu()
            data_numpy = data_numpy.numpy()
            # data_numpy = data_numpy[:1000,:]
            # Perform the test
            result = multivariate_normality(data_numpy, alpha=0.05)
            sum_p = sum_p + result[1]

            print('average_P_value:', sum_p / (sample_index + 1))



            # np.savetxt(path + 'samples' + '/enr_{}_{}.txt'.format(labels[sample_index], sample_index), z2.cpu().numpy(),
            #            fmt='%f %f %f')
            # z4 = F_inv_flow(z1, embeddings4g, F_flows, config['n_flows_F'])
            # np.savetxt(path + 'samples' + '/inv_{}_{}.txt'.format(labels[sample_index], sample_index), z4.cpu().numpy(),
            #            fmt='%f %f %f')
            # np.savetxt(path + 'samples' + '/ref_{}_{}.txt'.format(labels[sample_index], sample_index), z.cpu().numpy(),
            #            fmt='%f %f %f')


def encrypt(shape, means, samples, gussin_id):
    num = np.prod(shape)
    A = np.random.rand(num, num)
    A, R = np.linalg.qr(A)
    means = np.squeeze(means[gussin_id].cpu().numpy(), axis=0)
    means = np.expand_dims(means, axis=-1)
    b = means - A @ means
    samples = np.expand_dims(samples.cpu().numpy(), axis=-1)
    samples = A @ samples + b
    return samples


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("-c", "--config", type=str, default='../../configs/cif_train_cls_NN.yaml')


    args = parser.parse_args()

    if not args.config:
        parser.print_help()
    else:
        with open(args.config) as f:
            main(yaml.full_load(f))


