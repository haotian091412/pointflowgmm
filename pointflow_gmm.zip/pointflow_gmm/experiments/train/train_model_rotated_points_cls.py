import argparse
import datetime
import yaml
import os
import sys
import shutil

parent_path = os.path.dirname(os.path.dirname(os.path.abspath(os.path.dirname(__file__))))

sys.path.append(parent_path)

os.environ["CUDA_VISIBLE_DEVICES"] = "6"
import tqdm
from collections import OrderedDict
# import open3d as o3d
import torch
from torch import distributions
from torch.utils.data import DataLoader
import numpy as np
from torch.nn import functional as F
# from data.datasets_pointflow_ModelNet import (
#     CIFDatasetDecorator,
#     ModelNet10PointClouds,
#     CIFDatasetDecoratorMultiObject,
# )
from data.datasets_pointflow_Modelnet_new import (
    ModelNet
)
from data.datasets_pointflow_Modelnet_new_for_shape_cls import (
    ModelNet_cls
)
from data.datasets_pointflow_ScanObjectNN import (
    ScanObjectNNDatasetH5
)
from data.datasets_pointflow_ScanObjectNN_shape import (
    ScanObjectNNDatasetH5_cls
)
from data.datasets_Pointflow_segement import (
    CIFDatasetDecorator,
    ShapeNet15kPointClouds,
    CIFDatasetDecoratorMultiObject,
)
from utils.losses import loss_fun, loss_fun_gmm, loss_fun_one

from models.models import model_init, model_load, model_init_pointnet, model_load_pointnet
from models.flows import F_flow, G_flow
from models.pointnet import Encoder
from models.pointnet2_model import Pointnet2
from models.pointnet import Encoder,MLP_shape,MLP_point
from models.distributions import SSLGaussMixture
from models.flow_loss import FlowLoss
# from experiments.test.metrics_eval import metrics_eval
from models.flows import F_inv_flow
from utils.model_utils import *
from torch.utils.tensorboard import SummaryWriter
from scipy.stats import ortho_group
import random
from pointcloudc_utils.pointcloudc_utils.dataset import PointCloudC
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")


def main(config1: argparse.Namespace, config2: argparse.Namespace):
    # device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    if config1["use_random_dataloader"]:
        tr_sample_size = config1["tr_sample_size"]
        te_sample_size = config1["te_sample_size"]
        batch_size = config1["batch_size_if_random_split"]
    else:
        tr_sample_size = config1["tr_sample_size"]
        te_sample_size = config1["te_sample_size"]
        batch_size = config1["batch_size"]
    Az=torch.tensor(ortho_group.rvs(dim=3)).to(device).float()

    # cloud_pointflow = ShapeNet15kPointClouds(
    #     tr_sample_size=tr_sample_size,
    #     te_sample_size=te_sample_size,
    #     root_dir=config1["root_dir"],
    #     root_embs_dir=config1["root_embs_dir"],
    #     normalize_per_shape=config1["normalize_per_shape"],
    #     normalize_std_per_axis=config1["normalize_std_per_axis"],
    #     split=["train", "val"],
    #     scale=config1["scale"],
    #     random_subsample=True,
    # )
    # test_pointflow = ShapeNet15kPointClouds(
    #     tr_sample_size=tr_sample_size,
    #     te_sample_size=te_sample_size,
    #     root_dir=config2["root_dir"],
    #     root_embs_dir=config2["root_embs_dir"],
    #     normalize_per_shape=config2["normalize_per_shape"],
    #     normalize_std_per_axis=config2["normalize_std_per_axis"],
    #     split=["test"],
    #     scale=config2["scale"],
    #     random_subsample=True,
    # )
    #
    # if config1["use_random_dataloader"]:
    #     cloud_pointflow = CIFDatasetDecoratorMultiObject(
    #         cloud_pointflow, config1["num_of_points_per_object"]
    #     )
    #     test_pointflow = CIFDatasetDecoratorMultiObject(
    #         test_pointflow, config2["num_of_points_per_object"]
    #     )

    # data_cls=ModelNet_cls(config1)
    # processed_data=ModelNet_cls(config2)
    data_cls=PointCloudC('jitter_4',config1['subset'],'modelnet',config1)
    processed_data=PointCloudC('jitter_4',config2['subset'],'modelnet',config1)
    dataloader_cls = DataLoader(
        data_cls, batch_size=batch_size, shuffle=True,drop_last=True
    )
    dataloader_test = DataLoader(
        processed_data, batch_size=batch_size, shuffle=True
    )
    if config1['load_models']==True:
        pointnet = Pointnet2(
            emb_dim=config1["emb_dim"],
            normal_channel=False
        ).to(device)

        F_flows, G_flows, _, _, pointnet = model_load_pointnet(config1, device, pointnet)
        means = torch.load(config1["load_models_dir"] + "/weight/" + "means.pth")
        means_z = means['means_z']
        means_e = means['means_e']
        prior_e = SSLGaussMixture(means_e, device=device)
        prior_z = SSLGaussMixture(means_z, device=device)
    else:
        pointnet = Pointnet2(
            emb_dim=config1["emb_dim"],
            normal_channel=False
        ).to(device)
        F_flows,G_flows=None,None
        means_z=None
        means_e=None
        prior_z=None
        prior_e=None

    downstream_cls=Pointnet2(
        emb_dim=40,
        normal_channel=False
    ).to(device)
    mlp=MLP_shape(config1['num_point']*3,40).to(device)
    optimizer = torch.optim.Adam(pointnet.parameters(), lr=0.001)
    scheduler=torch.optim.lr_scheduler.StepLR(optimizer, step_size=500, gamma=0.5)

    if config1['subset'] == 'train':
        train(F_flows,G_flows,pointnet,downstream_cls,optimizer,scheduler,dataloader_cls,config1,Az,dataloader_test,means_z,mlp,prior_z)



    else:
        print('please choose the subset')


def train(F_flows,G_flows,pointnet,downstream_cls,optimizer,scheduler,dataloader,config,Az,test_dataloader,means_z,mlp,prior_z):


    train_writer = SummaryWriter(config["tensorboard_dir"] + "train")
    valid_writer = SummaryWriter(config["tensorboard_dir"] + "valid")

    global_step = 0
    best_e = 0
    A = np.random.rand(config['num_point'] * 3, config['num_point'] * 3)
    A, R = np.linalg.qr(A)
    A = torch.tensor(A).float().to(device)


    for i in range(config["n_epochs"]):
        mlp.train()
        pointnet.train()
        print("Epoch: {} / {}".format(i + 1, config["n_epochs"]))


        acc_w=0

        pbar = tqdm.tqdm(dataloader, desc="Batch", dynamic_ncols=True)
        optimizer.zero_grad()
        id = -1
        for j, datum in enumerate(pbar):
            # "idx_batch" -> indices of instances of a class

            embs_tr_batch = datum["train_points"]
            y = datum["labels"].to(device).long()


            if (j - 1) > 0 and (j - 1) % config["aggregation_steps"] == 0:
                optimizer.zero_grad()


            embs_tr_batch1 = embs_tr_batch.transpose(2, 1).to(device).float()

            embs_tr_batch2 = embs_tr_batch.reshape(embs_tr_batch.shape[0]*config['num_point'],-1).to(device).float()
            w_iter = pointnet(embs_tr_batch1)
            # e, e_ldetJ = G_flow(w_iter, G_flows, config["n_flows_G"], config["emb_dim"])
            # e_batch = (
            #     e.unsqueeze(dim=1)
            #     .expand(
            #         [e.shape[0], config['num_point'], e.shape[-1]]
            #     )
            #     .reshape((-1, e.shape[-1]))
            # )
            #
            # z, z_ldetJ = F_flow(embs_tr_batch2, e_batch, F_flows, config["n_flows_F"])
            # logit_z = prior_z.class_logits(z)
            # preds_z = torch.argmax(logit_z, dim=1)
            #
            # batch_size=int(z.shape[0]/config["num_point"])
            # translation = means_z[preds_z].reshape(batch_size, config['num_point'],3)
            # # translation = z.mean(dim=0)
            # z=z.reshape(batch_size,config['num_point'],3)
            # z=z-translation
            # z2 = torch.reshape(z, (-1, config['num_point'] * 3, 1))
            # z2 = torch.matmul(A, z2)
            # z_rotated = torch.reshape(z2, (batch_size,config['num_point'], 3))
            # z_rotated=z_rotated+translation
            # z_batch=z_rotated.reshape(batch_size,config['num_point']*3)
            # # z_rotated=torch.matmul(z2,Az)
            # # # z_batch=z_rotated.reshape(y.shape[0],2048,-1).transpose(2, 1)
            # #
            # w_down=mlp(z_batch)

            loss=F.nll_loss(w_iter,y)



            loss += loss.item()

            preds_w = torch.argmax(w_iter, dim=1)

            acc_w += (preds_w == y).float().mean().item()

            loss.backward()

            if j > 0 and j % config["aggregation_steps"] == 0:
                optimizer.step()
                scheduler.step()
            # test(pointnet, F_flows, G_flows, prior_e, prior_z, test_dataloader, device, config)
            # train_writer.add_scalar("loss_flow_z", loss_z, global_step=global_step)
            # train_writer.add_scalar("loss_flow_e", loss_e, global_step=global_step)
            # train_writer.add_scalar("loss_nll_e", loss_nll_e, global_step=global_step)
            train_writer.add_scalar("loss", loss, global_step=global_step)
            # train_writer.add_scalar("loss_nll_z", loss_nll_z, global_step=global_step)
            pbar.set_postfix(
                OrderedDict(
                    {
                        # "loss_z_avg": "%.4f" % (loss_acc_z / (j + 1)),
                        # "loss_e_avg": "%.4f" % (loss_acc_e / (j + 1)),
                        # "loss_nll_e": "%.4f" % (loss_nll_e / (j + 1)),
                        # "loss_nll_z": "%.4f" % (loss_nll_z / (j + 1)),
                        "acc_w": "%.4f" % (acc_w / (j + 1)),
                        # "acc_z": "%.4f" % (acc_z/(j+1)),
                        "loss": "%.4f"
                                    % ((loss) / (j + 1)),
                    }
                )
            )

            global_step += 1

        # test2(downstream_cls, F_flows, G_flows, pointnet, test_dataloader, config, Az)

        test(downstream_cls,F_flows,G_flows,pointnet,test_dataloader,config,A,means_z,mlp,prior_z)
        # test2(downstream_cls, F_flows, G_flows, pointnet, test_dataloader, config, Az)





    train_writer.close()
    valid_writer.close()


def sample(F_flows, G_flows, prior_e, prior_z, n_flows_F, epoch, step, path, mean_z, mean_e, device):
    for j in range(10):
        e = prior_e.sample((10,), gaussian_id=j)
        # means2 = mean_e[0]
        # e[0] = 0.7 * (e[0] - means2) + means2
        for sample_index in range(2):
            # z = torch.randn(2048, 3).float().to(device)
            z = prior_z.sample((2048,), gaussian_id=j)
            # means1 = mean_z[j].expand(2048, 3)
            # z = 0.7 * (z - means1) + means1
            # np.savetxt(path + 'samples' + '/noise{}_{}_epoch{}_{}.xyz'.format(j, sample_index, epoch, step),
            #            z.cpu().numpy(), fmt='%f %f %f')
            with torch.no_grad():
                targets = torch.LongTensor(2048, 1).fill_(sample_index)
                embeddings4g = e[targets].view(-1, 32)
                z = F_inv_flow(z, embeddings4g, F_flows, n_flows_F)
                if not os.path.exists(path + 'samples'):
                    os.makedirs(path + 'samples')
                np.savetxt(path + 'samples' + '/sample{}_{}_epoch{}_{}.xyz'.format(j, sample_index, epoch, step),
                           z.cpu().numpy(), fmt='%f %f %f')


def test(downstream_cls,F_flows,G_flows,pointnet,dataloader,config2,A,means_z,mlp,prior_z):

    pbar = tqdm.tqdm(dataloader, desc="Batch")
    acc_w = 0
    # downstream_cls.eval()
    pointnet.eval()
    mlp.eval()
    with torch.no_grad():
        for j, datum in enumerate(pbar):
            # "idx_batch" -> indices of instances of a class

            embs_tr_batch = datum["train_points"]
            y = datum["labels"].to(device).long()

            embs_tr_batch1 = embs_tr_batch.transpose(2, 1).to(device).float()

            embs_tr_batch2 = embs_tr_batch.reshape(embs_tr_batch.shape[0] * config2['num_point'], -1).to(device).float()
            w_iter = pointnet(embs_tr_batch1)
            # e, e_ldetJ = G_flow(w_iter, G_flows, config2["n_flows_G"], config2["emb_dim"])
            # e_batch = (
            #     e.unsqueeze(dim=1)
            #     .expand(
            #         [e.shape[0], config2['num_point'], e.shape[-1]]
            #     )
            #     .reshape((-1, e.shape[-1]))
            # )
            #
            # z, z_ldetJ = F_flow(embs_tr_batch2, e_batch, F_flows, config2["n_flows_F"])
            # logit_z = prior_z.class_logits(z)
            # preds_z = torch.argmax(logit_z, dim=1)
            #
            # batch_size = int(z.shape[0] / config2['num_point'])
            # translation = means_z[preds_z].reshape(batch_size, config2['num_point'], 3)
            # # translation = z.mean(dim=0)
            # z = z.reshape(batch_size, config2['num_point'], 3)
            # z = z - translation
            # z2 = torch.reshape(z, (-1, config2['num_point'] * 3, 1))
            # z2 = torch.matmul(A, z2)
            # z_rotated = torch.reshape(z2, (batch_size, config2['num_point'], 3))
            # z_rotated = z_rotated + translation
            # z_batch = z_rotated.reshape(batch_size, config2['num_point'] * 3)
            #
            # # z_rotated = torch.matmul(z, Az)
            # # z_batch = z_rotated.reshape(y.shape[0], 2048, -1).transpose(2, 1)
            #
            # w_down = mlp(z_batch)

            loss = F.nll_loss(w_iter, y)

            loss += loss.item()

            preds_w = torch.argmax(w_iter, dim=1)
            acc_w += (preds_w == y).float().mean().item()

            pbar.set_postfix(
                OrderedDict(
                    {
                        "acc_w": "%.4f" % (acc_w / (j + 1)),
                        "loss": "%.4f"
                                % ((loss) / (j + 1)),
                    }
                )
            )

def test2(downstream_cls,F_flows,G_flows,pointnet,dataloader,config2,Az):
    for k in [10,5,1,0.5]:
        print('epsilon',k)
        pbar = tqdm.tqdm(dataloader, desc="Batch")
        acc_w = 0
        downstream_cls.eval()
        pointnet.eval()
        with torch.no_grad():
            for j, datum in enumerate(pbar):
                # "idx_batch" -> indices of instances of a class

                embs_tr_batch = datum["train_points"].to(device).float()
                y = datum["labels"].to(device).long()

                sensitivity = 1/3
                embs_noise = add_laplacian_noise(embs_tr_batch[0], sensitivity, device, epsilon=k)
                # w_down = downstream_cls(embs_noise.expand(1,-1,-1).transpose(2, 1))
                w_down = downstream_cls(embs_noise.expand(1, -1, -1).transpose(2, 1))

                loss = F.nll_loss(w_down, y)

                loss += loss.item()

                preds_w = torch.argmax(w_down, dim=1)
                acc_w += (preds_w == y).float().mean().item()

                pbar.set_postfix(
                    OrderedDict(
                        {
                            "acc_w": "%.4f" % (acc_w / (j + 1)),
                            "loss": "%.4f"
                                    % ((loss) / (j + 1)),
                        }
                    )
                )

        acc_av_cls = 0
        for i in range(10):
            pbar = tqdm.tqdm(dataloader, desc="Batch")
            acc_w=0
            count = 0
            downstream_cls.eval()
            pointnet.eval()

            with torch.no_grad():
                for j, datum in enumerate(pbar):
                    # "idx_batch" -> indices of instances of a class
                    embs_tr_batch = datum["train_points"].to(device).float()
                    y = datum["labels"].to(device).long()
                    if y!=i:
                        continue
                    count+=1

                    sensitivity = 1/3
                    embs_noise = add_laplacian_noise(embs_tr_batch[0], sensitivity, device, epsilon=k)
                    w_down = downstream_cls(embs_noise.expand(1, -1, -1).transpose(2, 1))


                    loss = F.nll_loss(w_down, y)


                    loss += loss.item()

                    preds_w = torch.argmax(w_down, dim=1)
                    acc_w += (preds_w == y).float().mean().item()


                    pbar.set_postfix(
                        OrderedDict(
                            {
                                "acc_w": "%.4f" % (acc_w / (count + 1)),
                                "loss": "%.4f"
                                        % ((loss) / (j + 1)),
                            }
                        )
                    )
                acc_av_cls+=acc_w/(count+1)
        print(acc_av_cls/10)


def get_inv(pointnet, F_flows, G_flows, prior_e, prior_z, dataset, device, config, path, means):
    if not os.path.exists(path + 'samples'):
        os.makedirs(path + 'samples')
    else:
        shutil.rmtree(path + 'samples')
        os.makedirs(path + 'samples')
        print('delete orignal samples')
    samples = []
    shuffle_idx = list(range(len(dataset.points_for_point)))
    # random.Random(38383).shuffle(shuffle_idx)
    all_points = np.array([dataset.points_for_shape[i] for i in shuffle_idx])
    all_labels = np.array([dataset.labels_for_shape[i] for i in shuffle_idx])
    tr_idx = np.random.choice(10000, 2048)
    ref_samples = all_points[:, :, :3]
    labels = all_labels[:]
    # ref_samples = (ref_samples - np.mean(ref_samples, axis=(1, 2), keepdims=True)) / np.std(ref_samples, axis=(1, 2), keepdims=True)
    # ref_samples = torch.from_numpy(ref_samples).float().to(device)
    ref_samples = torch.from_numpy(ref_samples).float().to(device)
    # ref_samples = ref_samples.transpose(2, 1)
    # new_ref_samples = ref_samples.transpose(2, 1)
    # w = pointnet(ref_samples)
    # embs4g = G_flow(w, G_flows, config["n_flows_G"], config["emb_dim"])[0]
    for sample_index in tqdm.trange(5, desc="Sample"):
        z = ref_samples[sample_index]
        with torch.no_grad():
            # targets = torch.LongTensor(2048, 1).fill_(sample_index)
            # embeddings4g = embs4g[targets].view(-1, config['emb_dim'])
            # z = z.transpose(0, 1)
            # z1, z_ldetJ = F_flow(z, embeddings4g, F_flows, config["n_flows_F"])
            # np.savetxt(path + 'samples' + '/z{}_{}.xyz'.format(labels[sample_index], sample_index), z1.cpu().numpy(),
            #            fmt='%f %f %f')
            # z = z * std + mean
            # e = encrypt((32), means, embs4g[sample_index], labels[sample_index])
            # e = torch.squeeze(torch.from_numpy(e).to(device), dim=-1)
            # embeddings4g = torch.unsqueeze(e, dim=0)
            # embeddings4g = embeddings4g.expand(2048, 32).float()
            # embeddings4g = prior_e.sample((1,), gaussian_id=labels[sample_index][0])
            # embeddings4g = embeddings4g.expand(2048, 32).float()
            # # z = encrypt((2048*3), means, z, labels[sample_index])
            # # z = torch.squeeze(torch.from_numpy(z).to(device), dim=-1)
            # means1 = means[labels[sample_index][0]].expand(2048, 3)
            A = np.random.rand(2048, 2048)
            A, R = np.linalg.qr(A)
            A = torch.tensor(A).float().to(device)
            # z2 = torch.reshape((z1 - means1), (2048 * 3, 1))
            z1 = torch.matmul(A, z)
            # z2 = torch.reshape(z2, (2048, 3))
            # z3 = z2 * 0.7 + means1
            np.savetxt(path + 'samples' + '/inv{}_{}.txt'.format(labels[sample_index], sample_index), z1.cpu().numpy(),
                       fmt='%f %f %f')
            # z4 = F_inv_flow(z1, embeddings4g, F_flows, config['n_flows_F'])
            # np.savetxt(path + 'samples' + '/enr{}_{}.txt'.format(labels[sample_index], sample_index), z4.cpu().numpy(),
            #            fmt='%f %f %f')
            # np.savetxt(path + 'samples' + '/ref{}_{}.txt'.format(labels[sample_index], sample_index), z.cpu().numpy(),
            #            fmt='%f %f %f')


def encrypt(shape, means, samples, gussin_id):
    num = np.prod(shape)
    A = np.random.rand(num, num)
    A, R = np.linalg.qr(A)
    means = np.squeeze(means[gussin_id].cpu().numpy(), axis=0)
    means = np.expand_dims(means, axis=-1)
    b = means - A @ means
    samples = np.expand_dims(samples.cpu().numpy(), axis=-1)
    samples = A @ samples + b
    return samples

def add_laplacian_noise(point_cloud, sensitivity,device, epsilon):
    # Sensitivity is typically the maximum distance between two points in the point cloud
    # Calculate scale of Laplacian noise
    scale = sensitivity / epsilon

    # Generate Laplacian noise
    noise = torch.distributions.Laplace(loc=0, scale=scale).sample(point_cloud.size()).to(device)

    # Add noise to the point cloud
    noisy_point_cloud = point_cloud + noise
    return noisy_point_cloud


def calculate_sensitivity(point_cloud):
    # point_cloud is of shape [num_points, 3]

    # Calculate pairwise distances between all points
    point_cloud = point_cloud.unsqueeze(0)  # Add batch dimension
    pairwise_distances = torch.cdist(point_cloud, point_cloud, p=2).squeeze(0)

    # Find the maximum distance
    sensitivity = pairwise_distances.max().item()

    return sensitivity

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("-c1", "--config1", type=str, default='../../configs/cif_train_cls_new.yaml')
    parser.add_argument("-c2", "--config2", type=str, default='../../configs/cif_train_cls_new_eval.yaml')

    args = parser.parse_args()

    if not args.config1:
        parser.print_help()
    else:
        with open(args.config1) as f1:
            with open(args.config2) as f2:
                main(yaml.full_load(f1),yaml.full_load(f2))
