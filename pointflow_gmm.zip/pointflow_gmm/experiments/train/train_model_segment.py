import argparse
import datetime
import yaml
import os
import sys
import shutil

from scipy.stats import ortho_group
from pingouin import multivariate_normality
parent_path = os.path.dirname(os.path.dirname(os.path.abspath(os.path.dirname(__file__))))

sys.path.append(parent_path)

os.environ["CUDA_VISIBLE_DEVICES"] = "6"
import tqdm
from collections import OrderedDict
import open3d as o3d
import torch
from torch import distributions
from torch.utils.data import DataLoader
import numpy as np
from torch.nn import functional as F
from data.datasets_Pointflow_segement import (
    CIFDatasetDecorator,
    ShapeNet15kPointClouds,
    CIFDatasetDecoratorMultiObject,
)

from utils.losses import loss_fun_seg

from models.models import model_init, model_load, model_init_pointnet, model_load_pointnet
from models.flows import F_flow, G_flow
from models.pointnet import Encoder
from models.pointnet2_model import Pointnet2
from models.distributions import SSLGaussMixture
from models.flow_loss import FlowLoss

from models.flows import F_inv_flow
import random
from models.cosine_loss import cosine_loss,latent_loss,sample_ref,noise_loss
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
# from torch.utils.tensorboard import SummaryWriter

def get_mean(shape=(32), r=1, num_means=2, device=None):
    D = np.prod(shape)
    means = torch.zeros((num_means, D)).to(device)
    for i in range(num_means):
        means[i] = r * torch.randn(D)
    return means


def main(config: argparse.Namespace):
    # device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    # means_e = get_mean(shape=(32), r=3, num_means=16, device=device)
    # means_z = get_mean(shape=(3), r=3, num_means=4, device=device)
    n_means = 6  # 组数
    n_dim_z = 3  # 维数

    # 随机生成第一组均值
    means_z = np.random.randn(n_dim_z).reshape(1, -1)

    # 生成其余组均值
    while means_z.shape[0] < n_means:
        new_mean = 1.5 * np.random.randn(n_dim_z).reshape(1, -1)
        dists = np.linalg.norm(means_z - new_mean, axis=1)
        if np.min(dists) >= 3.5:
            means_z = np.vstack((means_z, new_mean))
    means_z = torch.from_numpy(means_z).to(device).float()
    n_means = 16  # 组数
    n_dim_e = config["emb_dim"]  # 维数

    # 随机生成第一组均值
    means_e = np.random.randn(n_dim_e).reshape(1, -1)

    # 生成其余组均值
    while means_e.shape[0] < n_means:
        new_mean = 1.5 * np.random.randn(n_dim_e).reshape(1, -1)
        dists = np.linalg.norm(means_e - new_mean, axis=1)
        if np.min(dists) >= 2.5:
            means_e = np.vstack((means_e, new_mean))
    means_e = torch.from_numpy(means_e).to(device).float()
    prior_e = SSLGaussMixture(means_e, device=device)
    prior_z = SSLGaussMixture(means_z, device=device)

    # prior_z = distributions.MultivariateNormal(
    #     torch.zeros(3), torch.eye(3)
    # )
    # prior_e = distributions.MultivariateNormal(
    #     torch.zeros(config["emb_dim"]), torch.eye(config["emb_dim"])
    # )
    # for i in range(6):
    #     z = prior_z.sample((2048,), gaussian_id=i)
    #     np.savetxt('output{}.xyz'.format(i), z.cpu().numpy(), fmt='%f %f %f')

    if config["use_random_dataloader"]:
        tr_sample_size = config["tr_sample_size"]
        te_sample_size = config["te_sample_size"]
        batch_size = config["batch_size_if_random_split"]
    else:
        tr_sample_size = config["tr_sample_size"]
        te_sample_size = config["te_sample_size"]
        batch_size = config["batch_size"]

    cloud_pointflow = ShapeNet15kPointClouds(
        tr_sample_size=tr_sample_size,
        te_sample_size=te_sample_size,
        root_dir=config["root_dir"],
        root_embs_dir=config["root_embs_dir"],
        normalize_per_shape=config["normalize_per_shape"],
        normalize_std_per_axis=config["normalize_std_per_axis"],
        split=["train", "val"],
        scale=config["scale"],
        random_subsample=True,
    )
    # test_pointflow = ShapeNet15kPointClouds(
    #     tr_sample_size=tr_sample_size,
    #     te_sample_size=te_sample_size,
    #     root_dir=config["root_dir"],
    #     root_embs_dir=config["root_embs_dir"],
    #     normalize_per_shape=config["normalize_per_shape"],
    #     normalize_std_per_axis=config["normalize_std_per_axis"],
    #     split=["test"],
    #     scale=config["scale"],
    #     random_subsample=True,
    # )

    if config["use_random_dataloader"]:
        cloud_pointflow = CIFDatasetDecoratorMultiObject(
            cloud_pointflow, config["num_of_points_per_object"]
        )
        # test_pointflow = CIFDatasetDecoratorMultiObject(
        #     test_pointflow, config["num_of_points_per_object"]
        # )



    dataloader_pointflow = DataLoader(
        cloud_pointflow, batch_size=batch_size, shuffle=True
    )
    # test_dataloader = DataLoader(
    #     test_pointflow, batch_size=batch_size, shuffle=True
    # )


    # print("Preparing model for " + config["categories"][0])

    # pointnet = Encoder(
    #     load_pretrained=config["load_pretrained"],
    #     pretrained_path=config["pretrained_path"],
    #     zdim=config["emb_dim"],
    # ).to(device)
    pointnet = Pointnet2(
        emb_dim=config["emb_dim"],
        normal_channel=False
    ).to(device)
    if config["load_models"]:
        F_flows, G_flows, optimizer, scheduler, pointnet = model_load_pointnet(config, device, pointnet)
        means = torch.load(config["load_models_dir"] +'weight/'+ "means.pth")
        means_z = means['means_z']
        means_e = means['means_e']
        prior_e = SSLGaussMixture(means_e, device=device)
        prior_z = SSLGaussMixture(means_z, device=device)
    else:
        # F_flows, G_flows, optimizer, scheduler = model_init(config, device)
        F_flows, G_flows, optimizer, scheduler, pointnet = model_init_pointnet(config, device, pointnet,0)

    if config['get_inv'] == True:
        get_inv(pointnet, F_flows, G_flows, prior_e, prior_z, cloud_pointflow, device, config, config['save_samples_dir'], means_z)
    else:
        for key in F_flows:
            F_flows[key].train()

        for key in G_flows:
            G_flows[key].train()
        pointnet.train()
        print("Starting training...")

        # train_writer = SummaryWriter(config["tensorboard_dir"] + "train")
        # valid_writer = SummaryWriter(config["tensorboard_dir"] + "valid")

        global_step = 0


        best_e = -90
        # test(pointnet, F_flows, G_flows, prior_e, prior_z, test_dataloader, device, config,0)
        for i in range(config["n_epochs"]):
            print("Epoch: {} / {}".format(i + 1, config["n_epochs"]))

            loss_acc_z = 0
            loss_acc_e = 0
            acc_z = 0
            acc_e = 0
            pbar = tqdm.tqdm(dataloader_pointflow, desc="Batch")

            optimizer.zero_grad()
            id = -1

            for j, datum in enumerate(pbar):
                # "idx_batch" -> indices of instances of a class
                idx_batch, embs_tr_batch = (datum["idx"], datum["train_points"])
                tr_batch = datum["points_to_decode"]
                label_point = datum["points_labels"]
                label_point = label_point.long()
                label = datum['labels']
                label = torch.squeeze(label, dim=-1).to(device)
                beta=datum["beta"]
                beta = (
                    (
                        beta.float()
                    )
                    .reshape((-1))
                )
                # np.savetxt('../../output.xyz', embs_tr_batch[0], fmt='%f %f %f')
                # gradient was applied in previous step, so we can reset it now
                if (j - 1) > 0 and (j - 1) % config["aggregation_steps"] == 0:
                    optimizer.zero_grad()

                if not config["use_random_dataloader"]:
                    b, n_points, coords_num = tr_batch.shape
                    idx_batch = (
                        idx_batch.unsqueeze(dim=-1)
                        .repeat(repeats=(1, n_points))
                        .reshape((-1,))
                    )

                num_points_per_object = tr_batch.shape[1]
                tr_batch = (
                    (
                            tr_batch.float()
                            + config["x_noise"] * torch.rand(tr_batch.shape)
                    )
                    .to(device)
                    .reshape((-1, 3))
                )
                label_point = label_point.to(device).reshape((-1,))
                embs_tr_batch1 = embs_tr_batch.transpose(2, 1)
                w_iter = pointnet(embs_tr_batch1.to(device))
                e, e_ldetJ = G_flow(w_iter, G_flows, config["n_flows_G"], config["emb_dim"])
                e_batch = (
                    e.unsqueeze(dim=1)
                    .expand(
                        [e.shape[0], num_points_per_object, e.shape[-1]]
                    )
                    .reshape((-1, e.shape[-1]))
                )
                z, z_ldetJ = F_flow(tr_batch, e_batch, F_flows, config["n_flows_F"])
                cos_loss = noise_loss(z, means_z, label_point, tr_batch, beta, device)
                for h in range(6):
                    np.savetxt('output{}.xyz'.format(h), z[label_point == h].cpu().detach().numpy(), fmt='%f %f %f')
                path = config["save_models_dir"]
                # get_inv(pointnet, F_flows, G_flows, prior_e, prior_z, test_cloud, device, config, path, means_z)
                logit_e = prior_e.class_logits(e)

                logit_z = prior_z.class_logits(z)

                loss_z, loss_e = loss_fun_seg(
                    z,
                    z_ldetJ,
                    prior_z,
                    e,
                    e_ldetJ,
                    prior_e,
                    label,
                    label_point,
                )
                loss = loss_z + loss_e + 0.0001*cos_loss
                loss_acc_z += loss_z.item()
                loss_acc_e += loss_e.item()

                preds_e = torch.argmax(logit_e, dim=1)
                acc_e += (preds_e == label).float().mean().item()
                preds_z = torch.argmax(logit_z, dim=1)
                acc_z += (preds_z == label_point).float().mean().item()
                loss.backward()
                # sample(F_flows, G_flows, prior_e, prior_z, config["n_flows_F"], i, path, means_z)
                # test(pointnet, F_flows, G_flows, prior_e, prior_z, test_dataloader, device, config)
                if j > 0 and j % config["aggregation_steps"] == 0:
                    optimizer.step()
                    scheduler.step()
                # train_writer.add_scalar("loss_flow_z", loss_z, global_step=global_step)
                # train_writer.add_scalar("loss_flow_e", loss_e, global_step=global_step)
                # train_writer.add_scalar("loss_nll_z", loss_nll_z, global_step=global_step)

                pbar.set_postfix(
                    OrderedDict(
                        {
                            # "loss_z_avg": "%.4f" % (loss_acc_z / (j + 1)),
                            # "loss_e_avg": "%.4f" % (loss_acc_e / (j + 1)),
                            "acc_e": "%.4f" % (acc_e / (j + 1)),
                            "acc_z": "%.4f" % (acc_z / (j + 1)),
                            # "loss_nll_z": "%.4f" % (loss_nll_z / (j + 1)),
                            # "loss_avg": "%.4f"
                            #             % ((loss_acc_z + loss_acc_e + loss_nll_z + loss_nll_e) / (j + 1)),
                        }
                    )
                )
                global_step += 1
                if j % 800 == 0 and j > 0:
                    # if (loss_acc_e / (j + 1)) < best_e and loss_e.item() < 0:
                    #     best_e = (loss_acc_e / (j + 1))
                    #     print("---save_best---")
                    #     print('best_acc_e_avg:', best_e)
                    #     path_best = config["save_models_dir"].replace('weight', 'weight_best')
                    #     try:
                    #         for key in F_flows:
                    #             torch.save(
                    #                 F_flows[key].module.state_dict(),
                    #                 path_best + "F_" + key + ".pth",
                    #             )
                    #         for key in G_flows:
                    #             torch.save(
                    #                 G_flows[key].module.state_dict(),
                    #                 path_best + "G_" + key + ".pth",
                    #             )
                    #     except:
                    #         for key in F_flows:
                    #             torch.save(
                    #                 F_flows[key].state_dict(), path_best + "F_" + key + ".pth"
                    #             )
                    #         for key in G_flows:
                    #             torch.save(
                    #                 G_flows[key].state_dict(), path_best + "G_" + key + ".pth"
                    #             )

                    #     torch.save(optimizer.state_dict(), path_best + "optimizer.pth")
                    #     torch.save(scheduler.state_dict(), path_best + "scheduler.pth")
                    #     torch.save(pointnet.state_dict(), path_best + "pointnet.pth")
                    #     torch.save({"means_e": means_e, "means_z": means_z}, path_best + "means.pth")
                    #     torch.save(i, path_best + "epoch.pth")
                    print("---save---")
                    path = config["save_models_dir"]
                    try:
                        for key in F_flows:
                            torch.save(
                                F_flows[key].module.state_dict(),
                                path + "F_" + key + ".pth",
                            )
                        for key in G_flows:
                            torch.save(
                                G_flows[key].module.state_dict(),
                                path + "G_" + key + ".pth",
                            )
                    except:
                        for key in F_flows:
                            torch.save(
                                F_flows[key].state_dict(), path + "F_" + key + ".pth"
                            )
                        for key in G_flows:
                            torch.save(
                                G_flows[key].state_dict(), path + "G_" + key + ".pth"
                            )

                    torch.save(optimizer.state_dict(), path + "optimizer.pth")
                    torch.save(scheduler.state_dict(), path + "scheduler.pth")
                    torch.save(pointnet.state_dict(), path + "pointnet.pth")
                    torch.save({"means_e": means_e, "means_z": means_z}, path + "means.pth")
                    torch.save(i, path + "epoch.pth")


            # test(pointnet, F_flows, G_flows, prior_e, prior_z, test_dataloader, device, config, i)

        # sample(F_flows, G_flows, prior_e, prior_z, config["n_flows_F"], i, path, means_z)
        # test(pointnet, F_flows, G_flows, prior_e, prior_z, test_dataloader, device, config, i)
        # try:
        #     for key in F_flows:
        #         torch.save(
        #             F_flows[key].module.state_dict(),
        #             path + "F_" + key + ".pth",
        #         )
        #     for key in G_flows:
        #         torch.save(
        #             G_flows[key].module.state_dict(),
        #             path + "G_" + key + ".pth",
        #         )
        # except:
        #     for key in F_flows:
        #         torch.save(
        #             F_flows[key].state_dict(), path + "F_" + key + ".pth"
        #         )
        #     for key in G_flows:
        #         torch.save(
        #             G_flows[key].state_dict(), path + "G_" + key + ".pth"
        #         )
        # torch.save(optimizer.state_dict(), path + "optimizer.pth")
        # torch.save(scheduler.state_dict(), path + "scheduler.pth")
        # torch.save(pointnet.state_dict(), path + "pointnet.pth")
        # torch.save({"means_e" : means_e, "means_z" : means_z}, path + "means.pth")

        # cov, mmd = metrics_eval(F_flows, config, device)
        #
        # valid_writer.add_scalar(
        #     "loss_z", loss_acc_z / (j + 1), global_step=global_step
        # )
        # valid_writer.add_scalar(
        #     "loss_e", loss_acc_e / (j + 1), global_step=global_step
        # )
        # valid_writer.add_scalar("cov", cov, global_step=global_step)
        # valid_writer.add_scalar("mmd", mmd, global_step=global_step)

    # train_writer.close()
    # valid_writer.close()


def sample(F_flows, G_flows, prior_e, prior_z, n_flows_F, epoch, path, mean_z):
    npart = [4, 2, 2, 4, 4, 3, 3, 2, 4, 2, 6, 2, 3, 3, 3, 3]
    n_points = {0: [1024, 512, 256, 256], 1: [256, 1024], 2: [1024, 512], 3: [256, 256, 256, 1024],
                4: [512, 1024, 512, 256], 5: [512, 512, 512],
                6: [256, 512, 1024], 7: [512, 512], 8: [1024, 1024, 1024, 1024], 9: [1024, 1024],
                10: [256, 256, 512, 1024, 256, 256],
                11: [1024, 1024], 12: [1024, 1024, 1024], 13: [1024, 1024, 1024], 14: [1024, 1024, 1024],
                15: [1024, 1024, 1024]}
    for j in range(16):
        e = prior_e.sample((1,), gaussian_id=j)
        for sample_index in range(npart[j]):
            z = prior_z.sample((n_points[j][sample_index],), gaussian_id=sample_index)
            # np.savetxt(path + 'samples' + '/noise{}_{}_epoch{}.xyz'.format(j, sample_index, epoch),
            #            z.cpu().numpy(), fmt='%f %f %f')
            with torch.no_grad():
                embeddings4g = e.expand(n_points[j][sample_index], 32)
                z = F_inv_flow(z, embeddings4g, F_flows, n_flows_F)
                if not os.path.exists(path + 'samples'):
                    os.makedirs(path + 'samples')
                np.savetxt(path + 'samples' + '/sample{}_{}_epoch{}.xyz'.format(j, sample_index, epoch),
                           z.cpu().numpy(), fmt='%f %f %f')


def test(pointnet, F_flows, G_flows, prior_e, prior_z, test_dataloader, device, config, epoch):
    pbar = tqdm.tqdm(test_dataloader, desc="Batch")
    path = config["save_models_dir"]
    acc_e = 0
    acc_z = 0
    acc_e_batch = 0
    npart = [4, 2, 2, 4, 4, 3, 3, 2, 4, 2, 6, 2, 3, 3, 3, 3]
    with torch.no_grad():
        for j, datum in enumerate(pbar):
            # "idx_batch" -> indices of instances of a class
            idx_batch, embs_tr_batch = (datum["idx"], datum["train_points"])
            tr_batch = datum["points_to_decode"]
            label_points = datum["points_labels"]
            label_points = label_points.long()
            labels = datum["labels"]
            labels = torch.squeeze(labels, dim=-1).to(device)
            # np.savetxt('../../output.xyz', embs_tr_batch[0], fmt='%f %f %f')
            # gradient was applied in previous step, so we can reset it now
            num_points_per_object = tr_batch.shape[1]
            tr_batch = (
                (
                    tr_batch.float()
                )
                .to(device)
                .reshape((-1, 3))
            )
            embs_tr_batch1 = embs_tr_batch.transpose(2, 1)
            w_iter = pointnet(embs_tr_batch1.to(device))
            label_points = label_points.to(device).reshape((-1,))
            # y = torch.squeeze(y, dim=-1).to(device)

            e, e_ldetJ = G_flow(w_iter, G_flows, config["n_flows_G"], config["emb_dim"])
            e_batch = (
                e.unsqueeze(dim=1)
                .expand(
                    [e.shape[0], num_points_per_object, e.shape[-1]]
                )
                .reshape((-1, e.shape[-1]))
            )

            z, z_ldetJ = F_flow(tr_batch, e_batch, F_flows, config["n_flows_F"])
            logit_e = prior_e.class_logits(e)
            preds_e = torch.argmax(logit_e, dim=1)
            # preds_e_batch = preds_e.repeat(60)
            # labels_batch = labels.repeat(60)
            acc_e += (preds_e == labels).float().mean().item()
            logit_z = prior_z.class_logits(z)
            preds_z = torch.argmax(logit_z, dim=1)
            if j < 1:
                for k in range(50):
                    z1, _ = F_flow(embs_tr_batch[k].to(device), e[None, k].expand(2048, 32), F_flows,
                                   config["n_flows_F"])
                    logit_z1 = prior_z.class_logits(z1)
                    preds_z1 = torch.argmax(logit_z1, dim=1)
                    # for p in range(npart[labels[k]]):
                    #     np.savetxt(path + 'samples' + '/seg{}_{}_epoch{}.xyz'.format(labels[k], p, epoch),
                    #                embs_tr_batch[k, preds_z1 == p].cpu().numpy(), fmt='%f %f %f')
            acc_z += (preds_z == label_points).float().mean().item()
            # acc_e_batch += (preds_e_batch == labels_batch and preds_z == label_points).float().mean().item()
            pbar.set_postfix(
                OrderedDict(
                    {
                        "acc_e": "%.4f" % (acc_e / (j + 1)),
                        "acc_z": "%.4f" % (acc_z / (j + 1)),
                        # "acc_e_batch": "%.4f" % (acc_e_batch / (j+1)),
                    }
                )
            )


def get_inv(pointnet, F_flows, G_flows, prior_e, prior_z, dataset, device, config, path, means_z):
    if not os.path.exists(path + 'samples'):
        os.makedirs(path + 'samples')
    else:
        shutil.rmtree(path + 'samples')
        os.makedirs(path + 'samples')
        print('delete orignal samples')

    tr_idx = np.random.choice(2100, 2048)
    ref_samples = dataset.all_points[:500, tr_idx, :]
    labels = dataset.dataset.all_labels[:500]
    labels_points=dataset.dataset.all_label_points[:,tr_idx]
    labels_points=torch.from_numpy(labels_points).float().to(device)
    ref_samples = torch.from_numpy(ref_samples).float().to(device)
    ref_samples = ref_samples.transpose(2, 1)
    w = pointnet(ref_samples)
    count=0
    A = np.random.rand(2048 * 3, 2048 * 3)
    A, R = np.linalg.qr(A)
    A = torch.tensor(A).float().to(device)
    embs4g = G_flow(w, G_flows, config["n_flows_G"], config["emb_dim"])[0]
    sum_p=0
    ref_samples = ref_samples.transpose(2, 1)
    for sample_index in tqdm.trange(500, desc="Sample"):
        # if labels[sample_index][0] !=0:
        #     continue
        # if count!=2:
        #     count=count+1
        #     continue
        # count=count+1

        z = ref_samples[sample_index]
        label_point=labels_points[sample_index].reshape(2048,1)
        label_point = label_point.long().to(device).reshape((-1,))

        with torch.no_grad():
            targets = torch.LongTensor(2048, 1).fill_(sample_index)
            embeddings4g = embs4g[targets].view(-1, config['emb_dim'])
            z1, z_ldetJ = F_flow(z, embeddings4g, F_flows, config["n_flows_F"])

            batch_size = int(z1.shape[0] / 2048)
            translation = means_z[label_point].expand(batch_size, 2048,3)
            z2 = z1.expand(batch_size, 2048, 3)
            z2 = z2 - translation
            z2 = sample_and_rotate(z2, label_point, batch_size, A)
            # translation = means_z[label_point].expand(batch_size, 2048, 3)
            # z2 = z2 + translation
            # Convert tensor to numpy array for scipy
            data_numpy = z2[0].cpu()
            data_numpy = data_numpy.numpy()
            # data_numpy = data_numpy[:1000, :]
            # Perform the test
            result = multivariate_normality(data_numpy, alpha=0.05)
            sum_p = sum_p + result[1]

            print('average_P_value:', sum_p / (sample_index + 1))





            # Az = torch.tensor(ortho_group.rvs(dim=3)).to(device).float()
            # z2 = torch.matmul(z1, Az)
            label_point = labels_points[sample_index].reshape(2048, 1)
            z4 = F_inv_flow(z2[0], embeddings4g, F_flows, config['n_flows_F'])
            z = torch.cat((z, label_point), dim=1)
            z1 = torch.cat((z1, label_point), dim=1)
            z2 = torch.cat((z2[0],label_point),dim=1)
            z4 = torch.cat((z4, label_point), dim=1)

            np.savetxt(path + 'samples' + '/inv_{}_{}.txt'.format(labels[sample_index][0], sample_index), z4.cpu().numpy(),
                       fmt='%f %f %f %f')
            # np.savetxt(path + 'samples' + '/enr_{}_{}.txt'.format(labels[sample_index][0], sample_index), z1.cpu().numpy(),
            #            fmt='%f %f %f %f')
            # np.savetxt(path + 'samples' + '/ref_{}_{}.txt'.format(labels[sample_index][0], sample_index),
            #            z.cpu().numpy(),
            #            fmt='%f %f %f %f')
            # break

def sample_and_rotate(z,label_point,batch_size,A):
    z_rotated=torch.zeros(2048*batch_size, 3).to(device).float()
    z=z.reshape( 2048*batch_size, 3)
    label_point=label_point.reshape(-1)
    for i in range(6):
        if i not in label_point:
            continue
        indices=torch.nonzero(label_point==i)
        indices=indices.reshape(-1)
        batch=z[indices]
        objects=int(batch.shape[0]/2048)+1
        remain = batch.shape[0]%2048
        if remain != 0:
            end_index=batch.shape[0]
            while remain != 0:
                add=2048-remain
                batch=torch.cat((batch,batch[:add]),dim=0)
                remain = batch.shape[0] % 2048
            batch = torch.reshape(batch, (objects, 2048 * 3, 1))
            batch = torch.matmul(A, batch)
            batch = torch.reshape(batch, ( objects , 2048, 3))
            batch=batch.reshape(objects*2048, 3)
            batch=batch[:end_index]
            z_rotated[indices] = batch
    z_rotated = z_rotated.reshape(batch_size,2048, 3)
    return z_rotated

def encrypt(shape, means, samples, gussin_id):
    num = np.prod(shape)
    A = np.random.rand(num, num)
    A, R = np.linalg.qr(A)
    means = np.squeeze(means[gussin_id].cpu().numpy(), axis=0)
    means = np.expand_dims(means, axis=-1)
    b = means - A @ means
    samples = np.expand_dims(samples.cpu().numpy(), axis=-1)
    samples = A @ samples + b
    return samples


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("-c", "--config", type=str, default='../../configs/cif_train_segment.yaml')
    args = parser.parse_args()

    if not args.config:
        parser.print_help()
    else:
        with open(args.config) as f:
            main(yaml.full_load(f))
