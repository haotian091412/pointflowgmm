import argparse
import datetime
import yaml
import os
import sys
import ot
parent_path = os.path.dirname(os.path.dirname(os.path.abspath(os.path.dirname(__file__))))

sys.path.append(parent_path)

os.environ["CUDA_VISIBLE_DEVICES"] = "0"
import tqdm
from collections import OrderedDict
# import open3d as o3d
import torch
from torch import distributions
from torch.utils.data import *

import numpy as np
from torch.nn import functional as F

from data.datasets_pointflow_Modelnet_new_for_shape_cls import (
    ModelNet_cls
)


from models.pointnet2_model import Pointnet2


def earth_movers_distance(point_cloud1, point_cloud2):
    # point_cloud1 and point_cloud2 should be 2D numpy arrays of shape [num_points, 3]

    # Convert to numpy arrays if they are PyTorch tensors
    if isinstance(point_cloud1, torch.Tensor):
        point_cloud1 = point_cloud1.cpu().detach().numpy()
    if isinstance(point_cloud2, torch.Tensor):
        point_cloud2 = point_cloud2.cpu().detach().numpy()

    # Compute pairwise distance matrix
    cost_matrix = np.linalg.norm(point_cloud1[:, np.newaxis, :] - point_cloud2[np.newaxis, :, :], axis=-1)

    # Uniform distribution over the points
    p = np.ones(point_cloud1.shape[0]) / point_cloud1.shape[0]
    q = np.ones(point_cloud2.shape[0]) / point_cloud2.shape[0]

    # Compute Earth Mover's Distance using the optimal transport package
    emd = ot.emd2(p, q, cost_matrix)

    return emd


def chamfer_distance(point_cloud1, point_cloud2):
    # point_cloud1 and point_cloud2 are of shape [batch_size, num_points, 3]

    # Compute pairwise distances
    x = point_cloud1.unsqueeze(2)  # [batch_size, num_points, 1, 3]
    y = point_cloud2.unsqueeze(1)  # [batch_size, 1, num_points, 3]

    dist = torch.norm(x - y, p=2, dim=-1)  # [batch_size, num_points, num_points]

    # For each point in point_cloud1, find the nearest point in point_cloud2
    dist1 = torch.min(dist, dim=2)[0]  # [batch_size, num_points]

    # For each point in point_cloud2, find the nearest point in point_cloud1
    dist2 = torch.min(dist, dim=1)[0]  # [batch_size, num_points]

    # Chamfer distance
    cd = torch.mean(dist1) + torch.mean(dist2)

    return cd
def fgsm_attack(pointnet_model, point_cloud, label, epsilon=0.01):
    # Set requires_grad to True for the input
    point_cloud.requires_grad = True

    # Forward pass
    output = pointnet_model(point_cloud)
    loss = torch.nn.CrossEntropyLoss()(output, label)

    # Backward pass
    loss.backward()

    # Compute the perturbation
    perturbation = epsilon * point_cloud.grad.sign()

    # Apply perturbation
    adversarial_point_cloud = point_cloud + perturbation
    return adversarial_point_cloud.detach()


# Example usage
# Assume `model` is a trained PointNet++ model
# `input_pc` is a (batch_size, N, 3) tensor representing the point cloud
# `label` is the ground truth class
def main(config: argparse.Namespace,config2: argparse.Namespace):
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    train_data = ModelNet_cls(config)
    test_data = ModelNet_cls(config2)
    dataloader = DataLoader(
        train_data, batch_size=50, shuffle=True
    )
    test_dataloader = DataLoader(
        test_data, batch_size=1
    )
    pointnet = Pointnet2(
        emb_dim=10,
        normal_channel=False
    ).to(device)
    optimizer = torch.optim.Adam(pointnet.parameters(), lr=1e-4)
    pointnet.train()
    for i in range(10):
        print("Epoch: {} / {}".format(i + 1, config["n_epochs"]))


        acc_e = 0

        pbar = tqdm.tqdm(dataloader, desc="Batch", dynamic_ncols=True)
        optimizer.zero_grad()
        id = -1
        for j, datum in enumerate(pbar):
            # "idx_batch" -> indices of instances of a class


            embs_tr_batch = datum["train_points"].to(device).float()
            y = datum["labels"].to(device).long()
            y=y.view(-1,1)
            y = torch.squeeze(y, dim=-1)

            optimizer.zero_grad()


            embs_tr_batch = embs_tr_batch.transpose(2, 1)
            w_iter = pointnet(embs_tr_batch)

            loss = F.cross_entropy(w_iter, y)
            preds_e = torch.argmax(w_iter, dim=-1)

            acc_e+=(preds_e == y).float().mean().item()
            loss.backward()
            optimizer.step()
            pbar.set_postfix(
                OrderedDict(
                    {

                        "acc_e": "%.4f" % (acc_e / (j + 1)),

                    }
                )
            )
    # adversarial_pc = fgsm_attack(pointnet, embs_tr_batch, y, epsilon=0.01)
    test(pointnet,test_dataloader, device)

def test(pointnet, test_dataloader, device):
    pbar = tqdm.tqdm(test_dataloader, desc="Batch")
    acc_e = 0
    CD=0
    EMD=0
    pointnet.eval()


    for j, datum in enumerate(pbar):
        # "idx_batch" -> indices of instances of a class
        embs_tr_batch = datum["train_points"].to(device)
        y = datum["labels"]
        y = y.view(-1, 1).to(device).long()
        y = torch.squeeze(y, dim=-1)
        embs_tr_batch = embs_tr_batch.transpose(2,1)
        adversarial_pc = fgsm_attack(pointnet, embs_tr_batch, y, epsilon=0.1)
        adversarial_pc = adversarial_pc.to(device)
        w_iter = pointnet(adversarial_pc)


        preds_e = torch.argmax(w_iter, dim=1)
        adversarial_pc = adversarial_pc.transpose(2, 1)
        embs_tr_batch=embs_tr_batch.transpose(2, 1)
        cd = chamfer_distance(adversarial_pc , embs_tr_batch)
        emd = earth_movers_distance(adversarial_pc[0], embs_tr_batch[0])
        CD += cd.item()
        EMD += emd
        acc_e += (preds_e == y).float().mean().item()

        pbar.set_postfix(
            OrderedDict(
                {
                    "acc": "%.4f" % (acc_e / (j + 1)),
                    "CD": "%.4f" % (CD / (j + 1)),
                    "EMD": "%.4f"
                           % (EMD / (j + 1))

                }
            )
        )

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("-c1", "--config1", type=str, default='../../configs/cif_train_cls_new.yaml')
    parser.add_argument("-c2", "--config2", type=str, default='../../configs/cif_train_cls_new_eval.yaml')

    args = parser.parse_args()

    if not args.config1:
        parser.print_help()
    else:
        with open(args.config1) as f1:
            with open(args.config2) as f2:
                main(yaml.full_load(f1), yaml.full_load(f2))
