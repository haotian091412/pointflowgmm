import torch
import numpy as np
import ot  # Python Optimal Transport
import argparse
import yaml
from models.models import model_init, model_load, model_init_pointnet, model_load_pointnet
from models.distributions import SSLGaussMixture
from models.pointnet2_model import Pointnet2
from data.datasets_pointflow_Modelnet_new import (
    ModelNet
)
import os
os.environ["CUDA_VISIBLE_DEVICES"] = "6"
from torch.utils.data import *
import tqdm
from models.flows import F_flow, G_flow
from scipy.stats import ortho_group
from collections import OrderedDict
from data.datasets_pointflow_Modelnet_new_for_shape_cls import (
    ModelNet_cls
)

def earth_movers_distance(point_cloud1, point_cloud2):
    # point_cloud1 and point_cloud2 should be 2D numpy arrays of shape [num_points, 3]

    # Convert to numpy arrays if they are PyTorch tensors
    if isinstance(point_cloud1, torch.Tensor):
        point_cloud1 = point_cloud1.cpu().detach().numpy()
    if isinstance(point_cloud2, torch.Tensor):
        point_cloud2 = point_cloud2.cpu().detach().numpy()

    # Compute pairwise distance matrix
    cost_matrix = np.linalg.norm(point_cloud1[:, np.newaxis, :] - point_cloud2[np.newaxis, :, :], axis=-1)

    # Uniform distribution over the points
    p = np.ones(point_cloud1.shape[0]) / point_cloud1.shape[0]
    q = np.ones(point_cloud2.shape[0]) / point_cloud2.shape[0]

    # Compute Earth Mover's Distance using the optimal transport package
    emd = ot.emd2(p, q, cost_matrix)

    return emd


def chamfer_distance(point_cloud1, point_cloud2):
    # point_cloud1 and point_cloud2 are of shape [batch_size, num_points, 3]

    # Compute pairwise distances
    x = point_cloud1.unsqueeze(2)  # [batch_size, num_points, 1, 3]
    y = point_cloud2.unsqueeze(1)  # [batch_size, 1, num_points, 3]

    dist = torch.norm(x - y, p=2, dim=-1)  # [batch_size, num_points, num_points]

    # For each point in point_cloud1, find the nearest point in point_cloud2
    dist1 = torch.min(dist, dim=2)[0]  # [batch_size, num_points]

    # For each point in point_cloud2, find the nearest point in point_cloud1
    dist2 = torch.min(dist, dim=1)[0]  # [batch_size, num_points]

    # Chamfer distance
    cd = torch.mean(dist1) + torch.mean(dist2)

    return cd


def add_laplacian_noise(point_cloud, sensitivity,device, epsilon):
    # Sensitivity is typically the maximum distance between two points in the point cloud
    # Calculate scale of Laplacian noise
    scale = sensitivity / epsilon

    # Generate Laplacian noise
    noise = torch.distributions.Laplace(loc=0, scale=scale).sample(point_cloud.size()).to(device)

    # Add noise to the point cloud
    noisy_point_cloud = point_cloud + noise
    return noisy_point_cloud


def calculate_sensitivity(point_cloud):
    # point_cloud is of shape [num_points, 3]

    # Calculate pairwise distances between all points
    point_cloud = point_cloud.unsqueeze(0)  # Add batch dimension
    pairwise_distances = torch.cdist(point_cloud, point_cloud, p=2).squeeze(0)

    # Find the maximum distance
    sensitivity = pairwise_distances.max().item()

    return sensitivity

def main(config: argparse.Namespace):
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    pointnet = Pointnet2(
        emb_dim=config["emb_dim"],
        normal_channel=False
    ).to(device)
    F_flows, G_flows, optimizer, scheduler, pointnet = model_load_pointnet(config, device, pointnet)
    means = torch.load(config["load_models_dir"] + "weight/" + "means.pth")
    means_z = means['means_z'].to(device)
    means_e = means['means_e'].to(device)
    prior_e = SSLGaussMixture(means_e, device=device)
    prior_z = SSLGaussMixture(means_z, device=device)

    processed_data = ModelNet_cls(config)
    dataloader = DataLoader(
        processed_data, batch_size=1, shuffle=True
    )

    Az = torch.tensor(ortho_group.rvs(dim=3)).to(device).float()
    pbar = tqdm.tqdm(dataloader, desc="Batch")

    CD=0
    EMD=0

    pointnet.eval()
    with torch.no_grad():
        for j, datum in enumerate(pbar):
            # "idx_batch" -> indices of instances of a class

            embs_tr_batch = datum["train_points"].to(device).float()
            y=datum["labels"].to(device).long()

            sensitivity=1/3
            # embs_noise=add_laplacian_noise(embs_tr_batch[0],sensitivity,device,epsilon=0.5)
            # cd = chamfer_distance(embs_noise.expand(1, -1, -1), embs_tr_batch.to(device))
            # emd = earth_movers_distance(embs_noise, embs_tr_batch[0].to(device))


            embs_tr_batch1 = embs_tr_batch.transpose(2, 1).to(device).float()

            embs_tr_batch2 = embs_tr_batch.reshape(embs_tr_batch.shape[0]*2048,-1).to(device).float()
            w_iter = pointnet(embs_tr_batch1)
            e, e_ldetJ = G_flow(w_iter, G_flows, config["n_flows_G"], config["emb_dim"])
            e_batch = (
                e.unsqueeze(dim=1)
                .expand(
                    [e.shape[0], 2048, e.shape[-1]]
                )
                .reshape((-1, e.shape[-1]))
            )

            z, z_ldetJ = F_flow(embs_tr_batch2, e_batch, F_flows, config["n_flows_F"])
            logits=prior_z.class_logits(z)
            z_pred=torch.argmax(logits, dim=-1)
            z_batch=z.reshape(y.shape[0],2048,-1)
            mean_point = means_z[z_pred]
            mean_point=mean_point.expand(1,2048,3)
            cd=chamfer_distance(z_batch-mean_point, embs_tr_batch)
            emd=earth_movers_distance(z_batch[0]-mean_point[0], embs_tr_batch[0])

            CD+=cd.item()
            EMD+=emd

            pbar.set_postfix(
                OrderedDict(
                    {
                        "CD": "%.4f" % (CD/(j+1) ),
                        "EMD": "%.4f"
                                % (EMD/(j+1))
                    }
                )
            )




if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument("-c", "--config", type=str, default='../../configs/cif_train_cls_new.yaml')

    args = parser.parse_args()

    if not args.config:
        parser.print_help()
    else:
        with open(args.config) as f:
            main(yaml.full_load(f))

