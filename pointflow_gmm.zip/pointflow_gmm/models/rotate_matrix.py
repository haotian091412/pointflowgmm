import torch.nn as nn
import torch.nn.functional as F
import torch

class MLP(nn.Module):
    def __init__(self, input_dim=1024, output_dim=10, hidden_dim1=512,hidden_dim2=256,hidden_dim3=256,hidden_dim4=256):
        super(MLP, self).__init__()
        self.fc1 = nn.Linear(input_dim, hidden_dim1)
        self.fc1_1 = nn.Linear(3, hidden_dim2)
        self.bn1_1 = nn.BatchNorm1d(hidden_dim2)
        self.bn1 = nn.BatchNorm1d(hidden_dim1)
        self.fc2 = nn.Linear(hidden_dim1, hidden_dim2)
        self.bn2 = nn.BatchNorm1d(hidden_dim2)
        self.fc2_1 = nn.Linear(hidden_dim2, 2*hidden_dim2)
        self.bn2_1 = nn.BatchNorm1d(2*hidden_dim2)
        self.fc3 = nn.Linear(2*hidden_dim2, hidden_dim3)
        self.bn3 = nn.BatchNorm1d(hidden_dim3)
        self.fc4 = nn.Linear(hidden_dim3, hidden_dim3)
        self.bn4 = nn.BatchNorm1d(hidden_dim3)
        self.fc5 = nn.Linear(hidden_dim3, hidden_dim4)
        self.bn5 = nn.BatchNorm1d(hidden_dim4)
        self.fc6 = nn.Linear(hidden_dim4, output_dim)


    def forward(self, x,y):
        x = self.fc1(x)
        x = F.relu(x)
        x=self.bn1(x)
        x=self.fc2(x)
        x = F.relu(x)
        x=self.bn2(x)
        if y is not None:
            y=self.fc1_1(y)
            y = F.relu(y)
            y=self.bn1_1(y)

            x=torch.cat((x,y),dim=1)
        else:
            x=self.fc2_1(x)
            x = F.relu(x)
            x=self.bn2_1(x)

        x = self.fc3(x)
        x = F.relu(x)
        x = self.bn3(x)

        x1=x

        x = self.fc4(x)
        x = F.relu(x)
        x=self.bn4(x)

        x=x+x1

        x=self.fc5(x)
        x = F.relu(x)
        x = self.bn5(x)

        x = self.fc6(x)


        return x