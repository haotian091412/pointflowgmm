import argparse
import os

import torch
import torch.nn as nn
from utils.model_utils import init_weights, optim, optim_updated
from models.architecture import F_AddNet, F_MulNet, G_AddNet, G_MulNet,F_noraml_MulNet,F_noraml_AddNet


def model_init(config: argparse.Namespace, device):
    F_flows = {}
    for n in range(config['n_flows_F']):
        for i in range(3):
            F_flows['MNet' + str(n) + '_' + str(i)] = F_MulNet(2, config['emb_dim'], config['n_neurons'], type_emb=config['type_emb'], arch_type=config['arch_type']).to(device)
            F_flows['MNet' + str(n) + '_' + str(i)].apply(init_weights)
            F_flows['ANet' + str(n) + '_' + str(i)] = F_AddNet(2, config['emb_dim'], config['n_neurons'], type_emb=config['type_emb'], arch_type=config['arch_type']).to(device)
            F_flows['ANet' + str(n) + '_' + str(i)].apply(init_weights)

    G_flows = {}
    for n in range(config['n_flows_G']):
        for i in range(2):
            G_flows['MNet' + str(n) + '_' + str(i)] = G_MulNet(config['emb_dim'] // 2, config['n_neurons'], arch_type=config['arch_type']).to(device)
            G_flows['MNet' + str(n) + '_' + str(i)].apply(init_weights)
            G_flows['ANet' + str(n) + '_' + str(i)] = G_AddNet(config['emb_dim'] // 2, config['n_neurons'], arch_type=config['arch_type']).to(device)
            G_flows['ANet' + str(n) + '_' + str(i)].apply(init_weights)

    if torch.cuda.device_count() > 1:
        for key in F_flows:
            F_flows[key] = nn.DataParallel(F_flows[key])
        for key in G_flows:
            G_flows[key] = nn.DataParallel(G_flows[key])

    optimizer = optim(F_flows, G_flows, config['l_rate'])
    scheduler = torch.optim.lr_scheduler.StepLR(optimizer, step_size=10, gamma=0.8)

    return F_flows, G_flows, optimizer, scheduler

def model_init_pointnet(config: argparse.Namespace, device, pointnet,local_rank):
    F_flows = {}
    for n in range(config['n_flows_F']):
        for i in range(3):
            if n<10:
                F_flows['MNet' + str(n) + '_' + str(i)] = F_MulNet(2, config['emb_dim'], config['n_neurons'], type_emb=config['type_emb'], arch_type=config['arch_type']).to(device)
                F_flows['MNet' + str(n) + '_' + str(i)].apply(init_weights)
                F_flows['ANet' + str(n) + '_' + str(i)] = F_AddNet(2, config['emb_dim'], config['n_neurons'], type_emb=config['type_emb'], arch_type=config['arch_type']).to(device)
                F_flows['ANet' + str(n) + '_' + str(i)].apply(init_weights)
            else:
                F_flows['MNet' + str(n) + '_' + str(i)] = F_noraml_MulNet(2, config['n_neurons'],arch_type=config['arch_type']).to(device)
                F_flows['MNet' + str(n) + '_' + str(i)].apply(init_weights)
                F_flows['ANet' + str(n) + '_' + str(i)] = F_noraml_AddNet(2, config['n_neurons'],arch_type=config['arch_type']).to(device)
                F_flows['ANet' + str(n) + '_' + str(i)].apply(init_weights)

    G_flows = {}
    for n in range(config['n_flows_G']):
        for i in range(2):
            G_flows['MNet' + str(n) + '_' + str(i)] = G_MulNet(config['emb_dim'] // 2, config['n_neurons'], arch_type=config['arch_type']).to(device)
            G_flows['MNet' + str(n) + '_' + str(i)].apply(init_weights)
            G_flows['ANet' + str(n) + '_' + str(i)] = G_AddNet(config['emb_dim'] // 2, config['n_neurons'], arch_type=config['arch_type']).to(device)
            G_flows['ANet' + str(n) + '_' + str(i)].apply(init_weights)

    # if torch.cuda.device_count() > 1:
    #     for key in F_flows:
    #         F_flows[key] = nn.DataParallel(F_flows[key])
    #     for key in G_flows:
    #         G_flows[key] = nn.DataParallel(G_flows[key])
    #     pointnet = nn.DataParallel(pointnet)
    if config['distributed']==True:
        for key in F_flows:
            F_flows[key] = nn.parallel.DistributedDataParallel(F_flows[key], device_ids=[local_rank])
        for key in G_flows:
            G_flows[key] = nn.parallel.DistributedDataParallel(G_flows[key],device_ids=[local_rank])
        pointnet = nn.parallel.DistributedDataParallel(pointnet, device_ids=[local_rank])
    optimizer = optim(F_flows, G_flows, config['l_rate'], pointnet)
    scheduler = torch.optim.lr_scheduler.StepLR(optimizer, step_size=int(1600/config['aggregation_steps']), gamma=0.5)

    return F_flows, G_flows, optimizer,scheduler,pointnet

def model_load(config: argparse.Namespace, device, train=True):
    path = config['load_models_dir']

    F_flows = {}
    for n in range(config['n_flows_F']):
        for i in range(3):
            F_flows['MNet' + str(n) + '_' + str(i)] = F_MulNet(2, config['emb_dim'], config['n_neurons'], type_emb=config['type_emb'], arch_type=config['arch_type']).to(device)
            F_flows['ANet' + str(n) + '_' + str(i)] = F_AddNet(2, config['emb_dim'], config['n_neurons'], type_emb=config['type_emb'], arch_type=config['arch_type']).to(device)

    G_flows = {}
    for n in range(config['n_flows_G']):
        for i in range(2):
            G_flows['MNet' + str(n) + '_' + str(i)] = G_MulNet(config['emb_dim'] // 2, config['n_neurons'], arch_type=config['arch_type']).to(device)
            G_flows['ANet' + str(n) + '_' + str(i)] = G_AddNet(config['emb_dim'] // 2, config['n_neurons'], arch_type=config['arch_type']).to(device)

    for key in F_flows:
        F_flows[key].load_state_dict(torch.load(path + r'F_' + key + r'.pth'))
    for key in G_flows:
        G_flows[key].load_state_dict(torch.load(path + r'G_' + key + r'.pth'))

    if torch.cuda.device_count() > 1:
        for key in F_flows:
            F_flows[key] = nn.DataParallel(F_flows[key])
        for key in G_flows:
            G_flows[key] = nn.DataParallel(G_flows[key])
    if train:
        optimizer = optim(F_flows, G_flows, config['l_rate'])
        optimizer.load_state_dict(torch.load(path + r'optimizer.pth'))

        scheduler = torch.optim.lr_scheduler.StepLR(optimizer, step_size=500, gamma=0.9)
        scheduler.load_state_dict(torch.load(path + r'scheduler.pth'))
    else:
        optimizer, scheduler = None, None

    return F_flows, G_flows, optimizer, scheduler

def model_load_pointnet(config: argparse.Namespace, device, pointnet):
    path = config['load_models_dir']

    F_flows = {}
    for n in range(config['n_flows_F']):
        for i in range(3):
            if n <= 10:
                F_flows['MNet' + str(n) + '_' + str(i)] = F_MulNet(2, config['emb_dim'], config['n_neurons'],
                                                                   type_emb=config['type_emb'],
                                                                   arch_type=config['arch_type']).to(device)
                F_flows['MNet' + str(n) + '_' + str(i)].apply(init_weights)
                F_flows['ANet' + str(n) + '_' + str(i)] = F_AddNet(2, config['emb_dim'], config['n_neurons'],
                                                                   type_emb=config['type_emb'],
                                                                   arch_type=config['arch_type']).to(device)
                F_flows['ANet' + str(n) + '_' + str(i)].apply(init_weights)
            else:
                F_flows['MNet' + str(n) + '_' + str(i)] = F_noraml_MulNet(2, config['n_neurons'],
                                                                          arch_type=config['arch_type']).to(device)
                F_flows['MNet' + str(n) + '_' + str(i)].apply(init_weights)
                F_flows['ANet' + str(n) + '_' + str(i)] = F_noraml_AddNet(2, config['n_neurons'],
                                                                          arch_type=config['arch_type']).to(device)
                F_flows['ANet' + str(n) + '_' + str(i)].apply(init_weights)

    G_flows = {}
    for n in range(config['n_flows_G']):
        for i in range(2):
            G_flows['MNet' + str(n) + '_' + str(i)] = G_MulNet(config['emb_dim'] // 2, config['n_neurons'], arch_type=config['arch_type']).to(device)
            G_flows['ANet' + str(n) + '_' + str(i)] = G_AddNet(config['emb_dim'] // 2, config['n_neurons'], arch_type=config['arch_type']).to(device)



    for key in F_flows:
        F_flows[key].load_state_dict(torch.load(path + r'/weight'+'/F_' + key + r'.pth'))

    for key in G_flows:
        G_flows[key].load_state_dict(torch.load(path + r'/weight'+'/G_' + key + r'.pth'))
    pointnet.load_state_dict(torch.load(path+ r"/weight" + "/pointnet.pth"))


    # for key in F_flows:
    #     F_flows[key] = nn.parallel.DistributedDataParallel(F_flows[key], device_ids=[local_rank])
    # for key in G_flows:
    #     G_flows[key] = nn.parallel.DistributedDataParallel(G_flows[key], device_ids=[local_rank])
    # pointnet = nn.parallel.DistributedDataParallel(pointnet, device_ids=[local_rank])
    # if train:
    #     optimizer = optim_pointnet(F_flows, G_flows, config['l_rate'], pointnet)
    #     # optimizer.load_state_dict(torch.load(path + r'optimizer.pth'))
    #
    #     scheduler = torch.optim.lr_scheduler.StepLR(optimizer, step_size=10, gamma=0.9)
    #     # scheduler.load_state_dict(torch.load(path + r'scheduler.pth'))
    # else:
    optimizer, scheduler = None, None

    return F_flows, G_flows, optimizer, scheduler, pointnet

def model_load_updated(config: argparse.Namespace, device, train=True):
    path = config['load_models_dir']

    F_flows = {}
    for n in range(config['n_flows_F']):
        for i in range(3):
            F_flows['MNet' + str(n) + '_' + str(i)] = F_MulNet(2, config['emb_dim'], config['n_neurons'], type_emb=config['type_emb'], arch_type=config['arch_type']).to(device)
            F_flows['ANet' + str(n) + '_' + str(i)] = F_AddNet(2, config['emb_dim'], config['n_neurons'], type_emb=config['type_emb'], arch_type=config['arch_type']).to(device)

    G_flows = {}
    for n in range(config['n_flows_G']):
        for i in range(2):
            G_flows['MNet' + str(n) + '_' + str(i)] = G_MulNet(config['emb_dim'] // 2, config['n_neurons'], arch_type=config['arch_type']).to(device)
            G_flows['ANet' + str(n) + '_' + str(i)] = G_AddNet(config['emb_dim'] // 2, config['n_neurons'], arch_type=config['arch_type']).to(device)

    for key in F_flows:
        F_flows[key].load_state_dict(torch.load(path + r'F_' + key + r'.pth'))
    for key in G_flows:
        G_flows[key].load_state_dict(torch.load(path + r'G_' + key + r'.pth'))

    if torch.cuda.device_count() > 1:
        for key in F_flows:
            F_flows[key] = nn.DataParallel(F_flows[key])
        for key in G_flows:
            G_flows[key] = nn.DataParallel(G_flows[key])

    if train:
        optimizer = optim_updated(F_flows, G_flows, config['l_rate'])
        optimizer.load_state_dict(torch.load(path + r'optimizer.pth'))

        scheduler = torch.optim.lr_scheduler.StepLR(optimizer, step_size=10, gamma=0.9)
        scheduler.load_state_dict(torch.load(path + r'scheduler.pth'))
    else:
        optimizer, scheduler = None, None

    return F_flows, G_flows, optimizer, scheduler