import argparse
from models.rotate_matrix import MLP
import torch
import torch.nn as nn
from utils.normalizing_rotate_utilis import init_weights, optim
from models.architecture import F_AddNet, F_MulNet, G_AddNet, G_MulNet,F_noraml_MulNet,F_noraml_AddNet

def model_init(config: argparse.Namespace, device):
    F_flows = {}
    for n in range(config['n_flows_F']):
        for i in range(3):
            F_flows['MNet' + str(n) + '_' + str(i)] = F_MulNet(2, config['emb_dim'], config['n_neurons'], type_emb=config['type_emb'], arch_type=config['arch_type']).to(device)
            F_flows['MNet' + str(n) + '_' + str(i)].apply(init_weights)
            F_flows['ANet' + str(n) + '_' + str(i)] = F_AddNet(2, config['emb_dim'], config['n_neurons'], type_emb=config['type_emb'], arch_type=config['arch_type']).to(device)
            F_flows['ANet' + str(n) + '_' + str(i)].apply(init_weights)

    G_flows = {}
    for n in range(config['n_flows_G']):
        for i in range(2):
            G_flows['MNet' + str(n) + '_' + str(i)] = G_MulNet(config['emb_dim'] // 2, config['n_neurons'], arch_type=config['arch_type']).to(device)
            G_flows['MNet' + str(n) + '_' + str(i)].apply(init_weights)
            G_flows['ANet' + str(n) + '_' + str(i)] = G_AddNet(config['emb_dim'] // 2, config['n_neurons'], arch_type=config['arch_type']).to(device)
            G_flows['ANet' + str(n) + '_' + str(i)].apply(init_weights)

    if torch.cuda.device_count() > 1:
        for key in F_flows:
            F_flows[key] = nn.DataParallel(F_flows[key])
        for key in G_flows:
            G_flows[key] = nn.DataParallel(G_flows[key])

    optimizer = optim(F_flows, G_flows, config['l_rate'])
    scheduler = torch.optim.lr_scheduler.StepLR(optimizer, step_size=10, gamma=0.8)

    return F_flows, G_flows, optimizer, scheduler

def model_init_pointnet(config: argparse.Namespace, device,prior_gmm ,local_rank):
    F_flows = {}
    for n in range(config['n_flows_F']):
        for i in range(3):
            F_flows['MNet' + str(n) + '_' + str(i)] = F_noraml_MulNet(2, config['n_neurons'],arch_type=config['arch_type']).to(device)
            F_flows['MNet' + str(n) + '_' + str(i)].apply(init_weights)
            F_flows['ANet' + str(n) + '_' + str(i)] = F_noraml_AddNet(2, config['n_neurons'],arch_type=config['arch_type']).to(device)
            F_flows['ANet' + str(n) + '_' + str(i)].apply(init_weights)

    Matrix={}
    for n in range(3):
        Matrix['Matrix'+str(n)] = MLP(input_dim=1, output_dim=9, hidden_dim1=16,hidden_dim2=32,hidden_dim3=128,hidden_dim4=64).to(device)
        Matrix['Matrix' + str(n)].apply(init_weights)
    # if torch.cuda.device_count() > 1:
    #     for key in F_flows:
    #         F_flows[key] = nn.DataParallel(F_flows[key])
    #     for key in G_flows:
    #         G_flows[key] = nn.DataParallel(G_flows[key])
    #     pointnet = nn.DataParallel(pointnet)
    if config['distributed']==True:
        for key in F_flows:
            F_flows[key] = nn.parallel.DistributedDataParallel(F_flows[key], device_ids=[local_rank])

        Matrix = nn.parallel.DistributedDataParallel(Matrix, device_ids=[local_rank])
    optimizer = optim(F_flows,Matrix,prior_gmm, config['l_rate'])
    scheduler = torch.optim.lr_scheduler.StepLR(optimizer, step_size=2000, gamma=0.5)

    return F_flows, Matrix, optimizer,scheduler