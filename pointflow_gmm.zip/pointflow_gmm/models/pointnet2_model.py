import torch.nn as nn
import torch.nn.functional as F
from models.pointnet2_utils import PointNetSetAbstraction,PointNetFeaturePropagation


class Pointnet2(nn.Module):
    def __init__(self,emb_dim,normal_channel=True,feature_dim=3):
        super(Pointnet2, self).__init__()
        in_channel = 3+feature_dim if normal_channel else 3
        self.normal_channel = normal_channel
        self.sa1 = PointNetSetAbstraction(npoint=512, radius=0.2, nsample=32, in_channel=in_channel, mlp=[64, 64, 128], group_all=False)
        self.sa2 = PointNetSetAbstraction(npoint=128, radius=0.4, nsample=64, in_channel=128 + 3, mlp=[128, 128, 256], group_all=False)
        self.sa3 = PointNetSetAbstraction(npoint=None, radius=None, nsample=None, in_channel=256 + 3, mlp=[256, 512, 1024], group_all=True)
        if self.normal_channel:
            self.fp3 = PointNetFeaturePropagation(1024 + 256, [256, 256])
            self.fp2 = PointNetFeaturePropagation(256 + 128, [256, 128])
            self.fp1 = PointNetFeaturePropagation(128 + feature_dim, [128, 128, 128])

            self.fc1_p = nn.Conv1d(128, 128, 1)
            self.fc2_p = nn.Conv1d(128, emb_dim, 1)
            self.dropout = nn.Dropout(0.5)
            self.bn1_p = nn.BatchNorm1d(128)
        else:
            self.fc1 = nn.Linear(1024, 512)
            self.bn1 = nn.BatchNorm1d(512)
            self.drop1 = nn.Dropout(0.4)
            self.fc2 = nn.Linear(512, 256)
            self.bn2 = nn.BatchNorm1d(256)
            self.drop2 = nn.Dropout(0.4)
            self.fc3 = nn.Linear(256, emb_dim)
        #

    def forward(self, xyz,featrue=None):
        B, _, _ = xyz.shape


        l1_xyz, l1_points = self.sa1(xyz, featrue)
        l2_xyz, l2_points = self.sa2(l1_xyz, l1_points)
        l3_xyz, l3_points = self.sa3(l2_xyz, l2_points)
        if featrue is not None:
            l2_points = self.fp3(l2_xyz, l3_xyz, l2_points, l3_points)
            l1_points = self.fp2(l1_xyz, l2_xyz, l1_points, l2_points)
            l0_points = self.fp1(xyz, l1_xyz, featrue, l1_points)
            x = F.relu(self.bn1_p(self.fc1_p(l0_points)))
            x = self.dropout(x)
            x = self.fc2_p(x)
            x = F.log_softmax(x, 1)

        else:
            x = l3_points.view(B, 1024)
            x = self.drop1(F.relu(self.bn1(self.fc1(x))))
            x = self.drop2(F.relu(self.bn2(self.fc2(x))))
            x = self.fc3(x)
            x=F.log_softmax(x,-1)


        return x
