import torch


def Matrix(y_matrix, tr_batch, Matrix_list):
    z=tr_batch
    regularization_term=torch.tensor(0.0)
    for n in range(3):
        matrix = Matrix_list['Matrix'+str(n)](y_matrix, None)
        z,regularization_term=Rotate(z,matrix)
        # regularization_term+=regularization_matrix(matrix)


    return z, regularization_term

def Rotate(z,matrix):
    regularization_term = torch.tensor(0.0)
    z_rotate=None
    for i in range(z.shape[0]):
        matrix_rotate=matrix[i].reshape(3,3)
        z_single=z[i].reshape(3,1)
        z_single_rotate=torch.matmul( matrix_rotate,z_single)
        if i==0:
            z_rotate=z_single_rotate
        else:
            z_rotate=torch.cat((z_rotate,z_single_rotate),1)
        det = torch.det(matrix_rotate)
        if abs(det.item()) < 1e-6:
            regularization_term += 1 / det
    return z_rotate.transpose(0,1),regularization_term

def regularization_matrix(matrix):
    loss_matrix=torch.tensor(0.0)
    l2=torch.nn.MSELoss()
    for single_matrix in matrix:
        single_matrix=single_matrix.reshape(3,3)
        mat_diff = torch.matmul(single_matrix, single_matrix.t())
        I = torch.eye(single_matrix.shape[0])
        mat_diff_loss=l2(mat_diff,I)
        loss_matrix += mat_diff_loss
    return torch.mean(loss_matrix)