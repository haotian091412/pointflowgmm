import torch
from torch.nn import *
from torch.nn.functional import cosine_similarity
def cosine_loss(z,means_z,y,device):
    cos_loss=torch.tensor(0.0).to(device)
    cos=CosineSimilarity(dim=1)
    for i,z_points in enumerate(z):
        n=len(z_points)
        mean=means_z[y[i]]
        for j in range(n):
            cos_loss += torch.sum(torch.abs(cos(z_points[j]-mean, z_points-mean.expand(n,3))))
    average_loss=cos_loss/z.shape[0]
    return average_loss
def noise_loss(z,means_z,y,tr_batch,beta,device):
    cos_loss=torch.tensor(0.0).to(device)
    cos=CosineSimilarity(dim=0)
    for i,z_point in enumerate(z):
        mean=means_z[y[i]]
        z_vector=z_point-mean
        cos_loss += torch.abs(cos(z_vector, tr_batch[i])-beta[i])
    average_loss=cos_loss
    return average_loss


def noise_loss2(z, means_z, y, tr_batch, beta, device):
    # Ensure all tensors are on the correct device
    z = z.to(device)
    means_z = means_z.to(device)
    y = y.to(device)
    tr_batch = tr_batch.to(device)
    beta = beta.to(device)

    # Gather the means corresponding to each point in the batch
    selected_means = means_z[y]

    # Compute the vector differences
    z_vectors = z - selected_means

    # Compute cosine similarity for the entire batch
    cos_sim = cosine_similarity(z_vectors, tr_batch, dim=1)

    # Compute the absolute differences with beta (one for each z)
    beta_diff = torch.abs(cos_sim - beta)

    # Sum up the losses
    cos_loss = beta_diff.sum()

    return cos_loss

def sample_ref(prior_z):
    ref=[]
    for gauss in prior_z.gaussians:
        points=gauss.sample((10000,))
        ref.append(points)
    return ref


def latent_loss(z,y,ref,indices,device):
    pdist = PairwiseDistance(p=1)
    dist=torch.tensor(0.0).to(device)
    for i in range(z.shape[0]):
        dist+=torch.sum(pdist(ref[y[i]][indices[i],:3],z[i]))
    dist=dist/(z.shape[0]*z.shape[1])
    return dist


if __name__ == '__main__':

    # Device (use 'cuda' if you have a GPU available)
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

    # Example inputs
    batch_size = 5  # Number of data points in the batch
    dim = 3  # Dimensionality of each data point
    num_classes = 4  # Number of classes

    # Input tensors
    z = torch.randn(batch_size, dim).to(device)  # Random latent vectors
    means_z = torch.randn(num_classes, dim).to(device)  # Random class means
    y = torch.randint(0, num_classes, (batch_size,)).to(device)  # Random class labels
    tr_batch = torch.randn(batch_size, dim).to(device)  # Random transformation batch
    beta = torch.randn(batch_size).to(device)  # Beta values, one per z (instead of per class)

    # Call the function
    loss = noise_loss(z, means_z, y, tr_batch, beta, device)
    loss2=noise_loss2(z, means_z, y, tr_batch, beta, device)

    # Output the result
    print("Noise Loss:", loss.item())
    print("Noise Loss2:", loss2.item())

