import argparse
import datetime
import yaml
import os
os.environ["CUDA_VISIBLE_DEVICES"] = '1'
import tqdm
from collections import OrderedDict
import open3d as o3d
import torch
from torch import distributions
from ptflops import get_model_complexity_info
from torch.utils.data import DataLoader
import numpy as np

from data.datasets_pointflow_Market import (
    MarketPointClouds,
    CIFDatasetDecoratorMultiObject,
)
from utils.losses import loss_fun
from loguru import logger
from models.models import model_init, model_load
from models.flows import F_flow, G_flow
from models.pointnet import Encoder
from models.pointnet2_model import PointNet2SSG
from experiments.test.metrics_eval import metrics_eval



from torch.utils.tensorboard import SummaryWriter


def main(config: argparse.Namespace):
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    prior_z = distributions.MultivariateNormal(
        torch.zeros(3), torch.eye(3)
    )
    prior_e = distributions.MultivariateNormal(
        torch.zeros(config["emb_dim"]), torch.eye(config["emb_dim"])
    )

    if config["use_random_dataloader"]:
        tr_sample_size = config["tr_sample_size"]
        te_sample_size = config["te_sample_size"]
        batch_size = config["batch_size_if_random_split"]
    else:
        tr_sample_size = config["tr_sample_size"]
        te_sample_size = config["te_sample_size"]
        batch_size = config["batch_size"]

    cloud_pointflow = MarketPointClouds(
        tr_sample_size=tr_sample_size,
        te_sample_size=te_sample_size,
        root_dir=config["root_dir"],
        root_embs_dir=config["root_embs_dir"],
        normalize_per_shape=config["normalize_per_shape"],
        normalize_std_per_axis=config["normalize_std_per_axis"],
        split="train",
        scale=config["scale"],
        categories=config["categories"],
        random_subsample=True,
    )

    if config["use_random_dataloader"]:
        cloud_pointflow = CIFDatasetDecoratorMultiObject(
            cloud_pointflow, config["num_of_points_per_object"]
        )

    if not os.path.exists(config["save_models_dir"]):
        os.makedirs(config["save_models_dir"])
    if not os.path.exists(config["save_models_dir_backup"]):
        os.makedirs(config["save_models_dir_backup"])

    dataloader_pointflow = DataLoader(
        cloud_pointflow, batch_size=batch_size, shuffle=True, drop_last=True
    )

    np.save(
        os.path.join(config["save_models_dir"], "train_set_mean.npy"),
        cloud_pointflow.all_points_mean,
    )
    np.save(
        os.path.join(config["save_models_dir"], "train_set_std.npy"),
        cloud_pointflow.all_points_std,
    )
    np.save(
        os.path.join(config["save_models_dir"], "train_set_idx.npy"),
        np.array(cloud_pointflow.shuffle_idx),
    )
    np.save(
        os.path.join(config["save_models_dir"], "val_set_mean.npy"),
        cloud_pointflow.all_points_mean,
    )
    np.save(
        os.path.join(config["save_models_dir"], "val_set_std.npy"),
        cloud_pointflow.all_points_std,
    )
    np.save(
        os.path.join(config["save_models_dir"], "val_set_idx.npy"),
        np.array(cloud_pointflow.shuffle_idx),
    )

    print("Preparing model for " + config["categories"][0])
    pointnet = PointNet2SSG(output_classes=32, init_points=512,
                            input_dims=3, dropout_prob=0.5, use_xyz=True).to(device)
    if config["load_models"]:
        F_flows, G_flows, pointnet, optimizer, scheduler = model_load(config, device, pointnet)
        params = list(pointnet.parameters())
        for key in G_flows:
            params1 = list(G_flows[key].parameters())
        epoch_idx = torch.load(config["load_models_dir"] + "epoch.pth")
        global_step = torch.load(config["load_models_dir"] + "global_step.pth")
        logger.info('loading model Epoch:{}'.format(epoch_idx))
    else:
        F_flows, G_flows, optimizer, scheduler = model_init(config, device, pointnet)
        epoch_idx = 0
        global_step = 0
    total = 0
    for key in F_flows:
        F_flows[key].train()
        total += sum([param.nelement() for param in F_flows[key].parameters()])
    print("Number of F_flows parameter: %.2fM" % (total / 1e6))
    total = 0
    for key in G_flows:
        G_flows[key].train()
        total += sum([param.nelement() for param in G_flows[key].parameters()])
    print("Number of G_flows parameter: %.2fM" % (total / 1e6))
    total = 0
    pointnet.train()
    total += sum([param.nelement() for param in pointnet.parameters()])
    print("Number of pointnet parameter: %.2fM" % (total / 1e6))

    print("Starting training...")

    train_writer = SummaryWriter(config["tensorboard_dir"] + "train")
    valid_writer = SummaryWriter(config["tensorboard_dir"] + "valid")



    # pointnet = Encoder(
    #     load_pretrained=config["load_pretrained"],
    #     pretrained_path=config["pretrained_path"],
    #     zdim=config["emb_dim"],
    # ).to(device)

    # if config["load_models"]:
    #     pointnet.load_state_dict(
    #         torch.load(os.path.join(config["load_models_dir"], "pointnet.pth"))
    #     )

    for i in range(epoch_idx, config["n_epochs"]):
        print("Epoch: {} / {}".format(i + 1, config["n_epochs"]))

        loss_acc_z = 0
        loss_acc_e = 0
        pbar = tqdm.tqdm(dataloader_pointflow, desc="Batch")

        optimizer.zero_grad()

        id = -1
        for j, datum in enumerate(pbar):
            # "idx_batch" -> indices of instances of a class
            idx_batch, embs_tr_batch = (datum["idx"], datum["train_points"])
            # if idx_batch[0] != id:
            #     id = idx_batch[0]
            #     pcd_o3d = o3d.geometry.PointCloud()
            #     pcd_o3d.points = o3d.utility.Vector3dVector(embs_tr_batch[0])
            #     o3d.io.write_point_cloud(config["save_models_dir"] + 'sampling/human{}.ply'.format(id), pcd_o3d)

            tr_batch = datum["points_to_decode"]

            # gradient was applied in previous step, so we can reset it now
            if (j-1)> 0 and (j - 1) % config["aggregation_steps"] == 0:
                optimizer.zero_grad()

            if not config["use_random_dataloader"]:
                b, n_points, coords_num = tr_batch.shape
                idx_batch = (
                    idx_batch.unsqueeze(dim=-1)
                        .repeat(repeats=(1, n_points))
                        .reshape((-1,))
                )

            num_points_per_object = tr_batch.shape[1]
            tr_batch = (
                (
                        tr_batch.float()
                        + config["x_noise"] * torch.rand(tr_batch.shape)
                )
                    .to(device)
                    .reshape((-1, 3))
            )

            w_iter = pointnet(embs_tr_batch.detach().to(device), embs_tr_batch.detach().to(device))
            w_iter = (
                w_iter.unsqueeze(dim=1)
                    .expand(
                    [w_iter.shape[0], num_points_per_object, w_iter.shape[-1]]
                )
                    .reshape((-1, w_iter.shape[-1]))
            )

            e, e_ldetJ = G_flow(w_iter, G_flows, config["n_flows_G"], config["emb_dim"])

            z, z_ldetJ = F_flow(tr_batch, e, F_flows, config["n_flows_F"])

            loss_z, loss_e = loss_fun(
                z,
                z_ldetJ,
                prior_z,
                e,
                e_ldetJ,
                prior_e,
            )
            loss = loss_e + 4*loss_z
            loss_acc_z += loss_z.item()
            loss_acc_e += loss_e.item()

            loss.backward()

            if j > 0 and j % config["aggregation_steps"] == 0:
                optimizer.step()

            train_writer.add_scalar("loss_z", loss_z, global_step=global_step)
            train_writer.add_scalar("loss_e", loss_e, global_step=global_step)
            train_writer.add_scalar("loss", loss_z + loss_e, global_step=global_step)
            train_writer.add_scalar("loss_z_avg", loss_acc_z / (j + 1), global_step=global_step)
            train_writer.add_scalar("loss_e_avg", loss_acc_e / (j + 1), global_step=global_step)
            train_writer.add_scalar("loss_avg", (loss_acc_z + loss_acc_e) / (j + 1), global_step=global_step)
            pbar.set_postfix(
                OrderedDict(
                    {
                        "loss_z_avg": "%.4f" % (loss_acc_z / (j + 1)),
                        "loss_e_avg": "%.4f" % (loss_acc_e / (j + 1)),
                        "loss_avg": "%.4f"
                                    % ((loss_acc_z + loss_acc_e) / (j + 1)),
                    }
                )
            )

            if global_step % 200 == 0 and global_step > 0:
                print("--------save model----------")
                path = config["save_models_dir"]
                try:
                    for key in F_flows:
                        torch.save(
                            F_flows[key].module.state_dict(),
                            path + "F_" + key + ".pth",
                        )
                    for key in G_flows:
                        torch.save(
                            G_flows[key].module.state_dict(),
                            path + "G_" + key + ".pth",
                        )
                except:
                    for key in F_flows:
                        torch.save(
                            F_flows[key].state_dict(), path + "F_" + key + ".pth"
                        )
                    for key in G_flows:
                        torch.save(
                            G_flows[key].state_dict(), path + "G_" + key + ".pth"
                        )
                torch.save(i + 1, path + "epoch.pth")
                torch.save(global_step, path + "global_step.pth")
                torch.save(optimizer.state_dict(), path + "optimizer.pth")
                torch.save(scheduler.state_dict(), path + "scheduler.pth")
                torch.save(pointnet.state_dict(), path + "pointnet.pth")

            global_step += 1

        scheduler.step()

        if (i + 1) % 2 == 0:
            path = config["save_models_dir_backup"]
        else:
            path = config["save_models_dir"]




#        cov, mmd = metrics_eval(F_flows, config, device)

        valid_writer.add_scalar(
            "loss_z", loss_acc_z / (j + 1), global_step=global_step
        )
        valid_writer.add_scalar(
            "loss_e", loss_acc_e / (j + 1), global_step=global_step
        )
#        valid_writer.add_scalar("cov", cov, global_step=global_step)
#        valid_writer.add_scalar("mmd", mmd, global_step=global_step)

    train_writer.close()
    valid_writer.close()


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("-c", "--config", type=str, default=None)
    args = parser.parse_args()

    if not args.config:
        parser.print_help()
    else:
        with open(args.config) as f:
            main(yaml.full_load(f))
