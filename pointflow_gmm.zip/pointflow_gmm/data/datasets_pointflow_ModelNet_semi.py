import os
import torch
import numpy as np
from torch.utils.data import Dataset, Sampler
from torch.utils import data
import random
import typing as t

# taken from https://github.com/optas/latent_3d_points/blob/8e8f29f8124ed5fc59439e8551ba7ef7567c9a37/src/in_out.py
synsetid_to_cate = {
    '02691156': 'airplane', '02773838': 'bag', '02801938': 'basket',
    '02808440': 'bathtub', '02818832': 'bed', '02828884': 'bench',
    '02876657': 'bottle', '02880940': 'bowl', '02924116': 'bus',
    '02933112': 'cabinet', '02747177': 'can', '02942699': 'camera',
    '02954340': 'cap', '02958343': 'car', '03001627': 'chair',
    '03046257': 'clock', '03207941': 'dishwasher', '03211117': 'monitor',
    '04379243': 'table', '04401088': 'telephone', '02946921': 'tin_can',
    '04460130': 'tower', '04468005': 'train', '03085013': 'keyboard',
    '03261776': 'earphone', '03325088': 'faucet', '03337140': 'file',
    '03467517': 'guitar', '03513137': 'helmet', '03593526': 'jar',
    '03624134': 'knife', '03636649': 'lamp', '03642806': 'laptop',
    '03691459': 'speaker', '03710193': 'mailbox', '03759954': 'microphone',
    '03761084': 'microwave', '03790512': 'motorcycle', '03797390': 'mug',
    '03928116': 'piano', '03938244': 'pillow', '03948459': 'pistol',
    '03991062': 'pot', '04004475': 'printer', '04074963': 'remote_control',
    '04090263': 'rifle', '04099429': 'rocket', '04225987': 'skateboard',
    '04256520': 'sofa', '04330267': 'stove', '04530566': 'vessel',
    '04554684': 'washer', '02992529': 'cellphone',
    '02843684': 'birdhouse', '02871439': 'bookshelf',
    # '02858304': 'boat', no boat in our dataset, merged into vessels
    # '02834778': 'bicycle', not in our taxonomy
}
cate_to_synsetid = {v: k for k, v in synsetid_to_cate.items()}


class Uniform15KPC(Dataset):
    def __init__(self, root_dir, root_embs_dir, subdirs, tr_sample_size=10000,
                 te_sample_size=10000, split='train', scale=1.,
                 normalize_per_shape=False, dataset='modelnet', random_subsample=False,
                 normalize_std_per_axis=False,
                 all_points_mean=None, all_points_std=None,
                 input_dim=3):
        self.root_dir = root_dir
        self.root_embs_dir = root_embs_dir
        self.split = split
        self.in_tr_sample_size = tr_sample_size
        self.in_te_sample_size = te_sample_size
        self.subdirs = subdirs
        self.scale = scale
        self.random_subsample = random_subsample
        self.input_dim = input_dim

        self.all_cate_mids = []
        self.cate_idx_lst = []
        self.all_points = []
        self.all_labels = []
        self.all_ws = []
        self.all_paths = []
        self.datasets = dataset
        # ModelNet5
        # labels = {"airplane":0, "chair":1, "bed":2, "sofa":3, "table":4}
        # ModelNet40
        labels = {"airplane":0, "bathtub":1, "bed":2, "bench":3, "bookshelf":4,
                  "bottle":5, "bowl":6, "car":7, "chair":8, "cone":9,
                  "cup":10, "curtain":11, "desk":12, "door":13, "dresser":14,
                  "flower_pot":15, "glass_box":16, "guitar":17, "keyboard":18, "lamp":19,
                  "laptop":20, "mantel":21, "monitor":22, "night_stand":23, "person":24,
                  "piano":25, "plant":26, "radio":27, "range_hood":28, "sink":29,
                  "sofa":30, "stairs":31, "stool":32, "table":33, "tent":34,
                  "toilet":35, "tv_stand":36, "vase":37, "wardrobe":38, "xbox":39}
        # labels = {"0": 0, "1": 1, "2": 2, "3": 3, "4": 4,
        #           "5": 5, "6": 6, "7": 7, "8": 8, "9": 9, "10": 10,
        #           "11": 11, "12": 12, "13": 13, "14": 14}
        # ModetNet
        # labels = {"airplane":0, "chair":1, "bed":2, "bookshelf":3, "sofa":4,
        #           "vase":5, "table":6, "toilet":7, "monitor":8, "bottle":9}
        # shapenet
        # labels = {"airplane":0, "chair":1, "table":2}
        # ModelNet10
        # "bathtub": 0, "chair": 1, "bed": 2, "desk": 3, "sofa": 4,"dresser":5, "table":6, "toilet":7, "monitor":8,
        # labels = {"bathtub": 0, "chair": 1, "bed": 2, "desk": 3, "sofa": 4,
        #           "dresser":5, "table":6, "toilet":7, "monitor":8, "night_stand":9}
        # labels = {"airplane": 0, "chair": 1}
        for cate_idx, subd in enumerate(self.subdirs):
            # NOTE: [subd] here is synset id
            # if subd not in labels:
            #     continue

            for sub_split in self.split:
                sub_path = os.path.join(root_dir, subd, sub_split)   # root_dir :modelnet  subd : airplane

                if not os.path.isdir(sub_path):
                    print("Directory missing : %s" % sub_path)
                    continue

                all_mids = []
                for x in os.listdir(sub_path):
                    if x.endswith('.txt'):
                        all_mids.append(os.path.join(sub_split, x[:]))
                    elif x.endswith('.npy'):
                        all_mids.append(os.path.join(sub_split, x[:]))
                    else:
                        continue
                # if self.split == 'train':
                all_mids = sorted(all_mids)
                # all_mids = all_mids[:2]
                # NOTE: [mid] contains the split: i.e. "train/<mid>" or "val/<mid>" or "test/<mid>"
                for i, mid in enumerate(all_mids):
                    # obj_fname = os.path.join(sub_path, x)
                    # 设置10%的有标签数据
                    inteval = 10
                    obj_fname = os.path.join(root_dir, subd, mid)
                    try:
                        if obj_fname.endswith('.txt'):
                            point_cloud = np.loadtxt(obj_fname, delimiter=',').astype(np.float32)[:, :3]
                            if split[0]=="train" and i%inteval!=0:
                                label = -1
                            else:
                                label = labels[subd]
                        elif obj_fname.endswith('.npy'):
                            point_cloud = np.load(obj_fname)
                            if split[0]=="train" and i%inteval!=0:
                                label = -1
                            else:
                            # idx = np.random.choice(point_cloud.shape[0], 8000)
                            # point_cloud = point_cloud[idx, :3] # (10k, 3)
                                label = labels[synsetid_to_cate[subd]]
                        # point_cloud = np.load(obj_fname)  # (15k, 3)
                    except:
                        continue

                    assert point_cloud.shape[0] == 10000
                    self.all_points.append(point_cloud[np.newaxis, ...])
                    self.all_labels.append(label)
                    self.all_paths.append(obj_fname)

        if dataset=='scanobjectnn':
            if self.split[0]=='train':
                self.datapath = './scanobject/h5_files/main_split_nobg/training_objectdataset.h5'
            elif self.split[0]=='test':
                self.datapath = './scanobject/h5_files/main_split_nobg/test_objectdataset.h5'
            with h5py.File(self.datapath, 'r') as f:
                dataset = f['data']
                label = f['label']
                self.all_points = dataset[()]
                self.all_labels = label[()]
                num = 0
                num1 = 0
                label = 0
                for i in range(len(self.all_points)):
                    if(self.all_labels[i]!=label):
                        label+=1
                        num1+=num
                    num+=1 
                    self.all_paths.append('scanobjectnn/{}/{}/{}_{}.txt'.format(label, self.split[0], label, i-num1))

        # Shuffle the index deterministically (based on the number of examples)
        self.shuffle_idx = list(range(len(self.all_points)))
        random.Random(38383).shuffle(self.shuffle_idx)
        self.all_points = [self.all_points[i] for i in self.shuffle_idx]
        self.all_labels = [self.all_labels[i] for i in self.shuffle_idx]
        self.all_paths = [self.all_paths[i] for i in self.shuffle_idx]
 
        # Normalization
        self.all_points = np.concatenate(self.all_points)  # (N, 15000, 3)
        # self.all_points = np.array(self.all_points)
        self.all_labels = np.array(self.all_labels)
        self.all_labels = np.expand_dims(self.all_labels, axis=-1)
        self.normalize_per_shape = normalize_per_shape
        self.normalize_std_per_axis = normalize_std_per_axis
        if all_points_mean is not None and all_points_std is not None:  # using loaded dataset stats
            self.all_points_mean = all_points_mean
            self.all_points_std = all_points_std
        elif self.normalize_per_shape:  # per shape normalization
            B, N = self.all_points.shape[:2]
            self.all_points_mean = self.all_points.mean(axis=1).reshape(B, 1, input_dim)
            if normalize_std_per_axis:
                self.all_points_std = self.all_points.reshape(B, N, -1).std(axis=1).reshape(B, 1, input_dim)
            else:
                self.all_points_std = self.all_points.reshape(B, -1).std(axis=1).reshape(B, 1, 1)
        else:  # normalize across the dataset
            self.all_points_mean = self.all_points.reshape(-1, input_dim).mean(axis=0).reshape(1, 1, input_dim)
            if normalize_std_per_axis:
                self.all_points_std = self.all_points.reshape(-1, input_dim).std(axis=0).reshape(1, 1, input_dim)
            else:
                self.all_points_std = self.all_points.reshape(-1).std(axis=0).reshape(1, 1, 1)
        # self.all_points = (self.all_points - self.all_points_mean) / self.all_points_std
        # for i in range(len(self.all_points)):
        #     # 获取当前点云的坐标
        #     coords = self.all_points[i]

        #     # 计算当前点云的中心位置
        #     center = np.mean(coords, axis=0)

        #     # 将当前点云的坐标减去中心位置
        #     coords -= center

        #     # 计算当前点云的最大距离
        #     max_dist = np.max(np.sqrt(np.sum(coords ** 2, axis=1)))

        #     # 将当前点云的坐标除以最大距离
        #     coords /= max_dist

        #     # 将归一化后的坐标保存回原数组
        #     self.all_points[i] = coords
        points_mean = np.mean(self.all_points, axis=(1, 2), keepdims=True)
        points_std = np.std(self.all_points, axis=(1, 2), keepdims=True)
        self.all_points = (self.all_points - points_mean) / points_std
        self.train_points = self.all_points[:, :]
        self.test_points = self.all_points[:, :]
        self.tr_sample_size = min(10000, tr_sample_size)
        self.te_sample_size = min(5000, te_sample_size)
        print("Total number of data:%d" % len(self.train_points))

        assert self.scale == 1, "Scale (!= 1) is deprecated"

    def get_pc_stats(self, idx):
        if self.normalize_per_shape:
            m = self.all_points_mean[idx].reshape(1, self.input_dim)
            s = self.all_points_std[idx].reshape(1, -1)
            return m, s

        return self.all_points_mean.reshape(1, -1), self.all_points_std.reshape(1, -1)

    def renormalize(self, mean, std):
        self.all_points = self.all_points * self.all_points_std + self.all_points_mean
        self.all_points_mean = mean
        self.all_points_std = std
        self.all_points = (self.all_points - self.all_points_mean) / self.all_points_std
        self.train_points = self.all_points[:, :10000]
        self.test_points = self.all_points[:, 10000:]

    def __len__(self):
        return len(self.train_points)

    def __getitem__(self, idx):
        tr_out = self.train_points[idx % len(self.train_points)]
        if self.random_subsample:
            tr_idxs = np.random.choice(tr_out.shape[0], self.tr_sample_size)
        else:
            tr_idxs = np.arange(self.tr_sample_size)

        tr_out = torch.from_numpy(tr_out[tr_idxs, :]).float()

        te_out = self.test_points[idx % len(self.train_points)]
        if self.random_subsample:
            te_idxs = np.random.choice(te_out.shape[0], self.te_sample_size)
        else:
            te_idxs = np.arange(self.te_sample_size)
        te_out = torch.from_numpy(te_out[te_idxs, :]).float()

        label = self.all_labels[idx% len(self.train_points)]
        path = self.all_paths[idx% len(self.train_points)]

        return {
            'idx': idx,
            'train_points': tr_out,
            'test_points': te_out,
            'labels': label,
            'paths': path,
        }



class ModelNet40PointClouds(Uniform15KPC):
    def __init__(self, root_dir="data/ModelNet40.PC15k",
                 root_embs_dir="data/ModelNet40.PC15k_embs",
                 tr_sample_size=10000, te_sample_size=2048,
                 split='train', scale=1., normalize_per_shape=False,
                 normalize_std_per_axis=False,
                 dataset='modelnet',
                 random_subsample=False,
                 all_points_mean=None, all_points_std=None):
        self.root_dir = root_dir
        self.root_embs_dir = root_embs_dir
        self.split = split
        # assert self.split in ['train', 'test']
        self.sample_size = tr_sample_size
        # self.cates = ["airplane", "chair", "bed", "bookshelf", "sofa",
        #           "vase", "table", "toilet", "monitor", "bottle"]
        # self.cates = ["airplane", "chair", "bed", "sofa", "table"]
        # ModelNet
        # self.cates = ["bathtub", "chair", "bed", "desk", "sofa",
        #             "dresser", "table", "toilet", "monitor", "night_stand"]
        # ModelNet40
        self.cates = ["airplane", "bathtub", "bed", "bench", "bookshelf",
                    "bottle", "bowl", "car", "chair", "cone",
                    "cup", "curtain", "desk", "door", "dresser",
                    "flower_pot", "glass_box", "guitar", "keyboard", "lamp",
                    "laptop", "mantel", "monitor", "night_stand", "person",
                    "piano", "plant", "radio", "range_hood", "sink",
                    "sofa", "stairs", "stool", "table", "tent",
                    "toilet", "tv_stand", "vase", "wardrobe", "xbox"]
        # self.cates = ["0", "1", "2", "3", "4", "5" , "6", "7", "8", "9",
        #               "10", "11", "12", "13", "14"]
        # self.cates = ["airplane", "chair"]
        # for cate in os.listdir(root_dir):
        #     if os.path.isdir(os.path.join(root_dir, cate)) \
        #             and os.path.isdir(os.path.join(root_dir, cate, 'train')) \
        #             and os.path.isdir(os.path.join(root_dir, cate, 'test')):
        #         self.cates.append(cate)
        # assert len(self.cates) == 40, "%s %s" % (len(self.cates), self.cates)

        # Aligned MN has same axis-order as SN
        self.gravity_axis = 1
        self.display_axis_order = [0, 2, 1]

        super(ModelNet40PointClouds, self).__init__(
            root_dir, root_embs_dir, self.cates,
            tr_sample_size=tr_sample_size,
            te_sample_size=te_sample_size, split=split, scale=scale,
            normalize_per_shape=normalize_per_shape,
            normalize_std_per_axis=normalize_std_per_axis,
            dataset=dataset,
            random_subsample=random_subsample,
            all_points_mean=all_points_mean, all_points_std=all_points_std,
            input_dim=3)


class ModelNet10PointClouds(Uniform15KPC):
    def __init__(self, root_dir="data/ModelNet10.PC15k",
                 root_embs_dir="data/ModelNet10.PC15k_embs",
                 tr_sample_size=10000, te_sample_size=2048,
                 split='train', scale=1., normalize_per_shape=False,
                 normalize_std_per_axis=False,
                 random_subsample=False,
                 all_points_mean=None, all_points_std=None):
        self.root_dir = root_dir
        self.root_embs_dir = root_embs_dir
        self.split = split
        assert self.split in ['train', 'test']
        self.cates = []
        for cate in os.listdir(root_dir):
            if os.path.isdir(os.path.join(root_dir, cate)) \
                    and os.path.isdir(os.path.join(root_dir, cate, 'train')) \
                    and os.path.isdir(os.path.join(root_dir, cate, 'test')):
                self.cates.append(cate)
        assert len(self.cates) == 10

        # That's prealigned MN
        # self.gravity_axis = 0
        # self.display_axis_order = [0,1,2]

        # Aligned MN has same axis-order as SN
        self.gravity_axis = 1
        self.display_axis_order = [0, 2, 1]

        super(ModelNet10PointClouds, self).__init__(
            root_dir, root_embs_dir, self.cates, tr_sample_size=tr_sample_size,
            te_sample_size=te_sample_size, split=split, scale=scale,
            normalize_per_shape=normalize_per_shape,
            normalize_std_per_axis=normalize_std_per_axis,
            random_subsample=random_subsample,
            all_points_mean=all_points_mean, all_points_std=all_points_std,
            input_dim=3)


class ShapeNet15kPointClouds(Uniform15KPC):
    def __init__(self, root_dir="data/ShapeNetCore.v2.PC15k",
                 root_embs_dir="data/ShapeNetCore.v2.PC15k_embs",
                 categories=['airplane'], tr_sample_size=10000, te_sample_size=2048,
                 split='train', scale=1., normalize_per_shape=False,
                 normalize_std_per_axis=False,
                 random_subsample=False,
                 all_points_mean=None, all_points_std=None):
        self.root_dir = root_dir
        self.root_embs_dir = root_embs_dir
        self.split = split
        # assert self.split in ['train', 'test', 'val']
        self.tr_sample_size = tr_sample_size
        self.te_sample_size = te_sample_size
        categories = ["airplane", "chair", "table"]
        self.cates = categories
        if 'all' in categories:
            self.synset_ids = list(cate_to_synsetid.values())
        else:
            self.synset_ids = [cate_to_synsetid[c] for c in self.cates]

        # assert 'v2' in root_dir, "Only supporting v2 right now."
        self.gravity_axis = 1
        self.display_axis_order = [0, 2, 1]

        super(ShapeNet15kPointClouds, self).__init__(
            root_dir, root_embs_dir, self.synset_ids,
            tr_sample_size=tr_sample_size,
            te_sample_size=te_sample_size,
            split=split, scale=scale,
            normalize_per_shape=normalize_per_shape,
            normalize_std_per_axis=normalize_std_per_axis,
            random_subsample=random_subsample,
            all_points_mean=all_points_mean, all_points_std=all_points_std,
            input_dim=3)


def init_np_seed(worker_id):
    seed = torch.initial_seed()
    np.random.seed(seed % 4294967296)


def _get_MN40_datasets_(args, data_dir=None):
    tr_dataset = ModelNet40PointClouds(
        split='train',
        tr_sample_size=args.tr_max_sample_points,
        te_sample_size=args.te_max_sample_points,
        root_dir=(args.data_dir if data_dir is None else data_dir),
        normalize_per_shape=args.normalize_per_shape,
        normalize_std_per_axis=args.normalize_std_per_axis,
        random_subsample=True)
    te_dataset = ModelNet40PointClouds(
        split='test',
        tr_sample_size=args.tr_max_sample_points,
        te_sample_size=args.te_max_sample_points,
        root_dir=(args.data_dir if data_dir is None else data_dir),
        normalize_per_shape=args.normalize_per_shape,
        normalize_std_per_axis=args.normalize_std_per_axis,
        all_points_mean=tr_dataset.all_points_mean,
        all_points_std=tr_dataset.all_points_std,
    )

    return tr_dataset, te_dataset


def _get_MN10_datasets_(args, data_dir=None):
    tr_dataset = ModelNet10PointClouds(
        split='train',
        tr_sample_size=args.tr_max_sample_points,
        te_sample_size=args.te_max_sample_points,
        root_dir=(args.data_dir if data_dir is None else data_dir),
        normalize_per_shape=args.normalize_per_shape,
        normalize_std_per_axis=args.normalize_std_per_axis,
        random_subsample=True)
    te_dataset = ModelNet10PointClouds(
        split='test',
        tr_sample_size=args.tr_max_sample_points,
        te_sample_size=args.te_max_sample_points,
        root_dir=(args.data_dir if data_dir is None else data_dir),
        normalize_per_shape=args.normalize_per_shape,
        normalize_std_per_axis=args.normalize_std_per_axis,
        all_points_mean=tr_dataset.all_points_mean,
        all_points_std=tr_dataset.all_points_std,
    )
    return tr_dataset, te_dataset


def rotate_point_cloud(batch_data):
    """ Randomly rotate the point clouds to augument the dataset
        rotation is per shape based along up direction
        Input:
          BxNx3 array, original batch of point clouds
        Return:
          BxNx3 array, rotated batch of point clouds
    """
    rotated_data = np.zeros(batch_data.shape, dtype=np.float32)
    for k in range(batch_data.shape[0]):
        rotation_angle = np.random.uniform() * 2 * np.pi
        cosval = np.cos(rotation_angle)
        sinval = np.sin(rotation_angle)
        rotation_matrix = np.array([[cosval, 0, sinval],
                                    [0, 1, 0],
                                    [-sinval, 0, cosval]])
        shape_pc = batch_data[k, ...]
        rotated_data[k, ...] = np.dot(shape_pc.reshape((-1, 3)), rotation_matrix)
    return rotated_data

def rotate_point_cloud_by_angle(batch_data, rotation_angle):
    """ Rotate the point cloud along up direction with certain angle.
        Input:
          BxNx3 array, original batch of point clouds
        Return:
          BxNx3 array, rotated batch of point clouds
    """
    rotated_data = np.zeros(batch_data.shape, dtype=np.float32)
    for k in range(batch_data.shape[0]):
        #rotation_angle = np.random.uniform() * 2 * np.pi
        cosval = np.cos(rotation_angle)
        sinval = np.sin(rotation_angle)
        rotation_matrix = np.array([[cosval, 0, sinval],
                                    [0, 1, 0],
                                    [-sinval, 0, cosval]])
        shape_pc = batch_data[k, ...]
        rotated_data[k, ...] = np.dot(shape_pc.reshape((-1, 3)), rotation_matrix)
    return rotated_data


def jitter_point_cloud(batch_data, sigma=0.01, clip=0.05):
    """ Randomly jitter points. jittering is per point.
        Input:
          BxNx3 array, original batch of point clouds
        Return:
          BxNx3 array, jittered batch of point clouds
    """
    B, N, C = batch_data.shape
    assert(clip > 0)
    jittered_data = np.clip(sigma * np.random.randn(B, N, C), -1*clip, clip)
    jittered_data += batch_data
    return jittered_data


def get_datasets(args):
    if args.dataset_type == 'shapenet15k':
        tr_dataset = ShapeNet15kPointClouds(
            categories=args.cates, split='train',
            tr_sample_size=args.tr_max_sample_points,
            te_sample_size=args.te_max_sample_points,
            scale=args.dataset_scale, root_dir=args.data_dir,
            normalize_per_shape=args.normalize_per_shape,
            normalize_std_per_axis=args.normalize_std_per_axis,
            random_subsample=True)
        te_dataset = ShapeNet15kPointClouds(
            categories=args.cates, split='val',
            tr_sample_size=args.tr_max_sample_points,
            te_sample_size=args.te_max_sample_points,
            scale=args.dataset_scale, root_dir=args.data_dir,
            normalize_per_shape=args.normalize_per_shape,
            normalize_std_per_axis=args.normalize_std_per_axis,
            all_points_mean=tr_dataset.all_points_mean,
            all_points_std=tr_dataset.all_points_std,
        )
    elif args.dataset_type == 'modelnet40_15k':
        tr_dataset, te_dataset = _get_MN40_datasets_(args)
    elif args.dataset_type == 'modelnet10_15k':
        tr_dataset, te_dataset = _get_MN10_datasets_(args)
    else:
        raise Exception("Invalid dataset type:%s" % args.dataset_type)

    return tr_dataset, te_dataset


def get_clf_datasets(args):
    return {
        'MN40': _get_MN40_datasets_(args, data_dir=args.mn40_data_dir),
        'MN10': _get_MN10_datasets_(args, data_dir=args.mn10_data_dir),
    }


def get_data_loaders(args):
    tr_dataset, te_dataset = get_datasets(args)
    train_loader = data.DataLoader(
        dataset=tr_dataset, batch_size=args.batch_size,
        shuffle=True, num_workers=args.num_workers, drop_last=True,
        worker_init_fn=init_np_seed)
    train_unshuffle_loader = data.DataLoader(
        dataset=tr_dataset, batch_size=args.batch_size,
        shuffle=False, num_workers=args.num_workers, drop_last=True,
        worker_init_fn=init_np_seed)
    test_loader = data.DataLoader(
        dataset=te_dataset, batch_size=args.batch_size,
        shuffle=False, num_workers=args.num_workers, drop_last=False,
        worker_init_fn=init_np_seed)

    loaders = {
        "test_loader": test_loader,
        'train_loader': train_loader,
        'train_unshuffle_loader': train_unshuffle_loader,
    }
    return loaders


class CIFDatasetDecorator(Dataset):
    def __init__(self, dataset: Uniform15KPC):
        super().__init__()
        self.dataset = dataset
        self.instance_point_train_indices = np.stack(
            np.meshgrid(
                range(dataset.train_points.shape[0]),
                range(dataset.train_points.shape[1])
            ), axis=-1
        ).transpose((1, 0, 2)).reshape((-1, 2))

        self.instance_point_test_indices = np.stack(
            np.meshgrid(
                range(dataset.test_points.shape[0]),
                range(dataset.test_points.shape[1])
            ), axis=-1
        ).transpose((1, 0, 2))

        self.test_point_range = np.arange(dataset.test_points.shape[1])

    def __getitem__(self, idx: int) -> t.Dict[str, torch.Tensor]:
        # rewritting the original __getitem__ of dataset from PointFlow
        # to omit additional sampling of points inside an instance of a class

        # -> index to a particular instance
        corresponding_original_index = (
            self.instance_point_train_indices[idx][0]
        )
        train_point_coords = self.instance_point_train_indices[idx]

        available_test_points = self.instance_point_test_indices[
            corresponding_original_index
        ]

        if self.dataset.random_subsample:
            # does not matter which testing_point we will take from the testing
            test_point_coords = available_test_points[
                np.random.choice(self.test_point_range)
            ]
        else:
            test_point_coords = available_test_points[0]

        tr_out = self.dataset.train_points[
            train_point_coords[0],
            train_point_coords[1]
        ]
        tr_out = torch.from_numpy(tr_out).float()

        te_out = self.dataset.test_points[
            test_point_coords[0],
            test_point_coords[1]
        ]
        te_out = torch.from_numpy(te_out).float()

        m, s = self.dataset.get_pc_stats(corresponding_original_index)
        cate_idx = self.dataset.cate_idx_lst[corresponding_original_index]
        sid, mid = self.dataset.all_cate_mids[corresponding_original_index]
        ws = self.dataset.all_ws[corresponding_original_index]

        return {
            "idx": corresponding_original_index,
            "train_points": tr_out,
            "test_points": te_out,
            "mean": m,
            "std": s,
            "cate_idx": cate_idx,
            "sid": sid,
            "mid": mid,
            "w": ws
        }

    def __len__(self) -> int:
        return len(self.instance_point_train_indices)

    def renormalize(self, mean, std):
        self.dataset.renormalize(mean, std)

    def get_pc_stats(self, idx):
        return self.dataset.get_pc_stats(idx)

    @property
    def all_points_mean(self):
        return self.dataset.all_points_mean

    @property
    def all_points_std(self):
        return self.dataset.all_points_std

    @property
    def shuffle_idx(self):
        return self.dataset.shuffle_idx

    @property
    def all_points(self):
        return self.dataset.all_points

    @property
    def all_labels(self):
        return self.dataset.all_labels

    @property
    def dataset_original_length(self):
        return len(self.dataset)


class CIFDatasetDecoratorMultiObject(Dataset):
    def __init__(
        self,
        dataset: Uniform15KPC,
        num_of_points_per_object: int
    ):
        super().__init__()
        self.dataset = dataset
        self.num_of_points_per_object = num_of_points_per_object

    def __getitem__(self, idx: int) -> t.Dict[str, torch.Tensor]:
        instance_index = (
            (idx * self.num_of_points_per_object)
            // self.dataset.train_points.shape[1]
        )

        data_dict = self.dataset[instance_index]
        
        start_index = (idx * self.num_of_points_per_object) % self.dataset.train_points.shape[1]
        end_index = min(
            start_index + self.num_of_points_per_object,
            self.dataset.train_points.shape[1]
        )

        # refinement to match dimensions for each tensor in the batch
        start_index = end_index - self.num_of_points_per_object

        indices = np.arange(start_index, end_index)
        np.random.shuffle(indices)

        points_to_decode = self.dataset.train_points[instance_index%len(self.dataset.train_points), indices]
        data = data_dict['train_points'].numpy()
        data = np.concatenate((data, points_to_decode), axis=0)
        if self.dataset.datasets=='scanobjectnn':
            if instance_index>2309:
                data = rotate_point_cloud(data[np.newaxis, :, :])
                data = jitter_point_cloud(data)
                data = data[0]
        data_dict["train_points"] = torch.from_numpy(data[:2048]).float()
        data_dict["points_to_decode"] = data[2048:]
        data_dict["train_idx"] = instance_index
        return data_dict

    def __len__(self) -> int:
        if self.dataset.split[0]=='train':
            if self.dataset.datasets=='scanobjectnn':
                return (
                    self.dataset.train_points.shape[0]*3
                    * self.dataset.train_points.shape[1]
                    // self.num_of_points_per_object
                )
            else:
                return (
                    self.dataset.train_points.shape[0]
                    * self.dataset.train_points.shape[1]
                    // self.num_of_points_per_object
                )
        if self.dataset.split[0]=='test':
            return (
                self.dataset.train_points.shape[0]
                * self.dataset.train_points.shape[1]
                // self.num_of_points_per_object
            )

    def renormalize(self, mean, std):
        self.dataset.renormalize(mean, std)

    def get_pc_stats(self, idx):
        return self.dataset.get_pc_stats(idx)

    @property
    def all_points_mean(self):
        return self.dataset.all_points_mean

    @property
    def all_points_std(self):
        return self.dataset.all_points_std

    @property
    def shuffle_idx(self):
        return self.dataset.shuffle_idx

    @property
    def all_points(self):
        return self.dataset.all_points

    @property
    def all_labels(self):
        return self.dataset.all_labels
    
    @property
    def dataset_original_length(self):
        return len(self.dataset)


if __name__ == "__main__":
    shape_ds = ShapeNet15kPointClouds(categories=['airplane'], split='val')
    x_tr, x_te = next(iter(shape_ds))
    print(x_tr.shape)
    print(x_te.shape)