'''
@author: Xu Yan
@file: ModelNet.py
@time: 2021/3/19 15:51
'''
import os
import numpy as np
import warnings
import pickle

import yaml
from tqdm import tqdm
from torch.utils.data import Dataset
import torch
import typing as t

warnings.filterwarnings('ignore')


def pc_normalize(pc):
    # normalize pc to [-1, 1]
    pc = pc - np.mean(pc, axis=0)
    if np.max(np.linalg.norm(pc, axis=1)) < 1e-6:
        pc = np.zeros_like(pc)
    else:
        pc = pc / np.max(np.linalg.norm(pc, axis=1))
    return pc


def farthest_point_sample(point, npoint):
    """
    Input:
        xyz: pointcloud data, [N, D]
        npoint: number of samples
    Return:
        centroids: sampled pointcloud index, [npoint, D]
    """
    N, D = point.shape
    xyz = point[:, :3]
    centroids = np.zeros((npoint,))
    distance = np.ones((N,)) * 1e10
    farthest = np.random.randint(0, N)
    for i in range(npoint):
        centroids[i] = farthest
        centroid = xyz[farthest, :]
        dist = np.sum((xyz - centroid) ** 2, -1)
        mask = dist < distance
        distance[mask] = dist[mask]
        farthest = np.argmax(distance, -1)
    point = point[centroids.astype(np.int32)]
    return point


class ModelNet(Dataset):
    def __init__(self, config):
        self.root = config['DATA_PATH']
        self.npoints_shape = config['N_POINTS_SHAPE']
        self.npoints_point = config['N_POINTS_POINT']
        self.use_normals = config['USE_NORMALS']
        self.num_category = config['NUM_CATEGORY']
        self.process_data = True
        self.uniform_for_shape = True
        self.uniform_for_point= False
        split = config['subset']
        self.subset = config['subset']
        self.with_color = config['with_color']
        self.num_of_points_per_object = config['num_of_points_per_object']
        self.beta = 2 * torch.rand(config['N_POINTS_POINT']) - 1

        if self.num_category == 10:
            self.catfile = os.path.join(self.root, 'modelnet10_shape_names.txt')
        else:
            self.catfile = os.path.join(self.root, 'modelnet40_shape_names.txt')

        self.cat = [line.rstrip() for line in open(self.catfile)]
        self.classes = dict(zip(self.cat, range(len(self.cat))))

        shape_ids = {}
        if self.num_category == 10:
            shape_ids['train'] = [line.rstrip() for line in open(os.path.join(self.root, 'modelnet10_train.txt'))]
            shape_ids['test'] = [line.rstrip() for line in open(os.path.join(self.root, 'modelnet10_test.txt'))]
        else:
            shape_ids['train'] = [line.rstrip() for line in open(os.path.join(self.root, 'modelnet40_train.txt'))]
            shape_ids['test'] = [line.rstrip() for line in open(os.path.join(self.root, 'modelnet40_test.txt'))]

        assert (split == 'train' or split == 'test')
        shape_names = ['_'.join(x.split('_')[0:-1]) for x in shape_ids[split]]
        self.datapath = [(shape_names[i], os.path.join(self.root, shape_names[i], shape_ids[split][i]) + '.txt') for i
                         in range(len(shape_ids[split]))]
        print('The size of %s data is %d' % (split, len(self.datapath)))


        # points load
        if self.uniform_for_shape:
            self.save_path_shape = os.path.join(self.root,
                                          'modelnet%d_%s_%dpts_fps.dat' % (self.num_category, split, self.npoints_shape))
        else:
            self.save_path_shape = os.path.join(self.root,
                                          'modelnet%d_%s_%dpts.dat' % (self.num_category, split, self.npoints_shape))
        if self.uniform_for_point:
            self.save_path_point = os.path.join(self.root,
                                          'modelnet%d_%s_%dpts_fps.dat' % (self.num_category, split, self.npoints_point))
        else:
            self.save_path_point = os.path.join(self.root,
                                          'modelnet%d_%s_%dpts.dat' % (self.num_category, split, self.npoints_point))

        if self.process_data:
            if not os.path.exists(self.save_path_shape):
                print('Processing data %s (only running in the first time)...' % self.save_path_shape)
                self.list_of_points = [None] * len(self.datapath)
                self.list_of_labels = [None] * len(self.datapath)

                for index in tqdm(range(len(self.datapath)), total=len(self.datapath)):
                    fn = self.datapath[index]
                    cls = self.classes[self.datapath[index][0]]
                    cls = np.array([cls]).astype(np.int32)
                    point_set = np.loadtxt(fn[1], delimiter=',').astype(np.float32)

                    if self.uniform_for_shape:
                        point_set = farthest_point_sample(point_set, self.npoints_shape)
                    else:
                        point_set = point_set[0:self.npoints, :]

                    self.list_of_points[index] = point_set
                    self.list_of_labels[index] = cls

                with open(self.save_path_shape, 'wb') as f:
                    pickle.dump([self.list_of_points, self.list_of_labels], f)
            else:
                print('Load processed data from %s...' % self.save_path_shape)
                with (open(self.save_path_shape, 'rb') as f):
                    list_of_points_for_shape, list_of_labels_for_shape = pickle.load(f)
                    self.points_for_shape, self.labels_for_shape = np.array(list_of_points_for_shape), np.array(
                        list_of_labels_for_shape)

            if not os.path.exists(self.save_path_point):
                print('Processing data %s (only running in the first time)...' % self.save_path_point)
                self.list_of_points = [None] * len(self.datapath)
                self.list_of_labels = [None] * len(self.datapath)

                for index in tqdm(range(len(self.datapath)), total=len(self.datapath)):
                    fn = self.datapath[index]
                    cls = self.classes[self.datapath[index][0]]
                    cls = np.array([cls]).astype(np.int32)
                    point_set = np.loadtxt(fn[1], delimiter=',').astype(np.float32)

                    if self.uniform_for_shape:
                        point_set = farthest_point_sample(point_set, self.npoints_point)
                    else:
                        point_set = point_set[0:self.npoints, :]

                    self.list_of_points[index] = point_set
                    self.list_of_labels[index] = cls

                with open(self.save_path_shape, 'wb') as f:
                    pickle.dump([self.list_of_points, self.list_of_labels], f)
            else:
                print('Load processed data from %s...' % self.save_path_point)
                with open(self.save_path_point, 'rb') as f:
                    list_of_points_for_point, list_of_labels_for_point = pickle.load(f)
                    self.points_for_point, self.labels_for_point = np.array(list_of_points_for_point), np.array(
                        list_of_labels_for_point)


    def __len__(self) -> int:
        return (
                self.points_for_point.shape[0]
                * self.points_for_point.shape[1]
                // self.num_of_points_per_object
        )

    def _get_item(self, idx):
        index = (
                (idx * self.num_of_points_per_object)
                // self.points_for_point.shape[1]
        )
        '''sample points for point module'''
        start_index = (idx * self.num_of_points_per_object) % self.points_for_point.shape[1]
        end_index = min(
            start_index + self.num_of_points_per_object,
            self.points_for_shape.shape[1]
        )

        # refinement to match dimensions for each tensor in the batch
        start_index = end_index - self.num_of_points_per_object

        indices = np.arange(start_index, end_index)
        np.random.shuffle(indices)
        points_to_decode = self.points_for_point[index, indices, :3]
        beta=self.beta[indices]
        '''get sampled points for shape module'''
        if self.process_data:
            point_set, label = self.points_for_shape[index], self.labels_for_shape[index]
        else:
            fn = self.datapath[index]
            cls = self.classes[self.datapath[index][0]]
            label = np.array([cls]).astype(np.int32)
            point_set = np.loadtxt(fn[1], delimiter=',').astype(np.float32)

            if self.uniform_for_shape:
                point_set = farthest_point_sample(point_set, self.npoints)
            else:
                point_set = point_set[0:self.npoints, :]

        point_set[:, :3] = pc_normalize(point_set[:, :3])
        if not self.use_normals:
            point_set = point_set[:, :3]
        if self.with_color:
            color = np.ones(point_set.shape) * 0.6
            point_set = np.concatenate([point_set, color], axis=-1)

        return point_set, label[0], points_to_decode,beta

    def __getitem__(self, idx):
        points, label, points_to_decode,beta = self._get_item(idx)
        pt_idxs = np.arange(0, points.shape[0])  # 2048
        if self.subset == 'train':
            np.random.shuffle(pt_idxs)
        current_points = points[pt_idxs].copy()
        #current_points = torch.from_numpy(current_points).float()
        return {'train_points':current_points, 'labels':label, 'points_to_decode':points_to_decode, 'beta':beta}

    @property
    def all_labels(self):
        return self.labels_for_point



if __name__ == '__main__':
    config_path='../configs/cif_train_cls_new.yaml'
    with open(config_path, 'r') as f:
        config=yaml.full_load(f)
    train_data=ModelNet(config)
    print(train_data[0])
