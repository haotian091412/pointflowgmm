import os
import torch
from torch.utils.data import Dataset, DataLoader
import h5py
import numpy as np
import yaml


class ScanObjectNNDatasetH5(Dataset):
    def __init__(self, config):
        self.subset=config['subset']
        if self.subset == 'train':
            self.h5_file = os.path.join(config['DATA_PATH'],'training_objectdataset.h5')
        else:
            self.h5_file = os.path.join(config['DATA_PATH'],'test_objectdataset.h5')
        self.num_of_points_per_object = config['num_of_points_per_object']

        with h5py.File(self.h5_file, 'r') as f:
            self.data = f['data'][:]
            self.labels = f['label'][:]
        print('The size of %s data is %d' % (self.subset, len(self.data)))

    def __len__(self):
        return (
                self.data.shape[0]
                * self.data.shape[1]
                // self.num_of_points_per_object
        )

    def _get_item(self, idx):
        index = (
                (idx * self.num_of_points_per_object)
                // self.data.shape[1]
        )
        '''sample points for point module'''
        start_index = (idx * self.num_of_points_per_object) % self.data.shape[1]
        end_index = min(
            start_index + self.num_of_points_per_object,
            self.data.shape[1]
        )

        # refinement to match dimensions for each tensor in the batch
        start_index = end_index - self.num_of_points_per_object

        indices = np.arange(start_index, end_index)
        np.random.shuffle(indices)
        points_to_decode = self.data[index, indices, :3]
        '''get sampled points for shape module'''

        point_set, label = self.data[index], self.labels[index]


        return point_set, label, points_to_decode

    def __getitem__(self, idx):
        points, label, points_to_decode = self._get_item(idx)

        pt_idxs = np.arange(0, points.shape[0])  # 2048
        if self.subset == 'train':
            np.random.shuffle(pt_idxs)
        current_points = points[pt_idxs].copy()

        return {'train_points':current_points, 'labels':label, 'points_to_decode':points_to_decode}


